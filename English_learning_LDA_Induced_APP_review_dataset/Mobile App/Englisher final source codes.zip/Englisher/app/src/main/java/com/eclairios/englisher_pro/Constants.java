package com.eclairios.englisher_pro;

public class Constants {
    static String APIKEY="qDM8D96ZANIHGU0DoDYenYOwFwrgo87z6yYvjawLurFaEDddlm23iCAZYdt0";
  //  static String APIKEY="7VcvKb3TZTYAzRHImRIBptwYh9AbjzWPJCCZy1iLR2m6eZ3gRw2IiAvyTvO6";

}
