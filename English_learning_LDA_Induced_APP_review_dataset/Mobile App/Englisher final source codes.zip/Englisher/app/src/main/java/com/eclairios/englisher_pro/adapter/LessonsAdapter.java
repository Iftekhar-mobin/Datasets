package com.eclairios.englisher_pro.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.eclairios.englisher_pro.R;

import com.eclairios.englisher_pro.model.LessonsItem;

import java.util.ArrayList;


public class LessonsAdapter extends RecyclerView.Adapter<LessonsAdapter.ViewHolder> {

    private ArrayList<LessonsItem> mValues;
    private Context mContext;
    protected ItemListener mListener;

    public LessonsAdapter(Context context, ArrayList<LessonsItem> values, ItemListener itemListener) {
        mValues = values;
        mContext = context;
        mListener=itemListener;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView textView;
        private TextView imageView;
        private RelativeLayout relativeLayout;
        private LessonsItem item;

        public ViewHolder(View v) {
            super(v);
            v.setOnClickListener(this);
            textView = (TextView) v.findViewById(R.id.textView);
            imageView = (TextView) v.findViewById(R.id.imageView);
            relativeLayout = (RelativeLayout) v.findViewById(R.id.relativeLayout);
        }

        public void setData(LessonsItem item) {
            this.item = item;
            textView.setText(item.text);
            imageView.setText("Lesson "+item.header);
          //  relativeLayout.setBackgroundColor(Color.parseColor(item.color));
        }

        @Override
        public void onClick(View view) {
            if (mListener != null) {
                mListener.onItemClick(item);
            }
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.row_item_lesson, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int position) {
        viewHolder.setData(mValues.get(position));
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public interface ItemListener {
        void onItemClick(LessonsItem item);
    }
}