package com.eclairios.englisher_pro;

/**
 * Created by khan on 3/1/2018.
 */

public class Book {

    //Setter Getter Class


    String book_id;
    String chapter_id;
    int chapter_img;
    String chapter_name;
    String chapter_page_number;
    String chapter_page_text;
    String chapter_page_text_turk;
    String chapter_image1;
    String chapter_image2;
    String contact_number;
    int contact_image;
    int flag_first;
    int flag_second;
    String page_title;
    String page_title_turk;
    String contact_name;

    public String getContact_name() {
        return contact_name;
    }

    public void setContact_name(String contact_name) {
        this.contact_name = contact_name;
    }


    public int getChapter_img() {
        return chapter_img;
    }

    public void setChapter_img(int chapter_img) {
        this.chapter_img = chapter_img;
    }



    public String getContact_number() {
        return contact_number;
    }

    public void setContact_number(String contact_number) {
        this.contact_number = contact_number;
    }

    public int getContact_image() {
        return contact_image;
    }

    public void setContact_image(int contact_image) {
        this.contact_image = contact_image;
    }

    public int getFlag_first() {
        return flag_first;
    }

    public void setFlag_first(int flag_first) {
        this.flag_first = flag_first;
    }

    public int getFlag_second() {
        return flag_second;
    }

    public void setFlag_second(int flag_second) {
        this.flag_second = flag_second;
    }


    public String getChapter_name() {
        return chapter_name;
    }

    public void setChapter_name(String chapter_name) {
        this.chapter_name = chapter_name;
    }
    public String getPage_title() {
        return page_title;
    }

    public void setPage_title(String page_title) {
        this.page_title = page_title;
    }


    public String getBook_id() {
        return book_id;
    }

    public void setBook_id(String book_id) {
        this.book_id = book_id;
    }

    public String getChapter_id() {
        return chapter_id;
    }

    public void setChapter_id(String chapter_id) {
        this.chapter_id = chapter_id;
    }

    public String getChapter_page_number() {
        return chapter_page_number;
    }

    public void setChapter_page_number(String chapter_page_number) {
        this.chapter_page_number = chapter_page_number;
    }

    public String getChapter_page_text() {
        return chapter_page_text;
    }

    public void setChapter_page_text(String chapter_page_text) {
        this.chapter_page_text = chapter_page_text;
    }

    public String getChapter_image1() {
        return chapter_image1;
    }

    public void setChapter_image1(String chapter_image1) {
        this.chapter_image1 = chapter_image1;
    }

    public String getChapter_image2() {
        return chapter_image2;
    }

    public void setChapter_image2(String chapter_image2) {
        this.chapter_image2 = chapter_image2;
    }



    public String getPage_title_turk() {
        return page_title_turk;
    }

    public void setPage_title_turk(String page_title_turk) {
        this.page_title_turk = page_title_turk;
    }



    public String getChapter_page_text_turk() {
        return chapter_page_text_turk;
    }

    public void setChapter_page_text_turk(String chapter_page_text_turk) {
        this.chapter_page_text_turk = chapter_page_text_turk;
    }



}
