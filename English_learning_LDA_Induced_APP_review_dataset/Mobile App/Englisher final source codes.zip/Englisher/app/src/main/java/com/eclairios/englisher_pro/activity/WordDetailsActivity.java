package com.eclairios.englisher_pro.activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.eclairios.englisher_pro.DataBaseHelper;
import com.eclairios.englisher_pro.R;
import com.eclairios.englisher_pro.TopExceptionHandler;
import com.eclairios.englisher_pro.model.Word_details_model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Random;

public class WordDetailsActivity extends AppCompatActivity  implements TextToSpeech.OnInitListener{



    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    TextToSpeech tts;
    TextToSpeech tts2;
    String textforspeech;
    String textforspeech2;
    HashMap<String, String> map;
    HashMap<String, String> map2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Thread.setDefaultUncaughtExceptionHandler(new TopExceptionHandler(this));
        setContentView(R.layout.activity_word_details);


        String title = PreferenceManager.getDefaultSharedPreferences(this).getString("chapter", "null");
      //  setTitle("Weakness");

        map = new HashMap<String, String>();
        map2 = new HashMap<String, String>();

        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);

        tts=new TextToSpeech(this,this);
        tts2=new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {

                if(status == TextToSpeech.SUCCESS){

                    tts2.setSpeechRate(0.8f);
                    int result=tts2.setLanguage(new Locale("bn"));
                    if(result==TextToSpeech.LANG_MISSING_DATA ||
                            result==TextToSpeech.LANG_NOT_SUPPORTED){
                        Log.e("error", "This Language is not supported");
                    }
                    else{
                        ConvertTextToSpeech2(textforspeech2);
                    }
                }
                else
                    Log.e("error", "Initilization Failed!");
            }
        });


        /**
         AdView mAdView = findViewById(R.id.adView);
         AdRequest adRequest = new AdRequest.Builder().build();
         mAdView.loadAd(adRequest);
         MobileAds.initialize(this, getResources().getString(R.string.google_app_id));
         mInterstitialAd = new InterstitialAd(this);
         mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial_ad_unit_id));
         mInterstitialAd.loadAd(new AdRequest.Builder().build());
         */


        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);


//         use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);



/**     BackGroundTask task = new BackGroundTask(this, "https://soccer.sportmonks.com/api/v2.0/Books?include=leagues,sort=name&api_token=" + Constants.APIKEY, pBar);
 task.delegate = com.eclairios.englisher.activity..this;
 task.executeTask(); */

        ArrayList<Word_details_model> Records = new ArrayList();
        DataBaseHelper dataBaseHelper=new DataBaseHelper(this);
        Records=dataBaseHelper.ShowWordDetails(getIntent().getStringExtra("word"));
        String[] testArr=new String[Records.size()];
        ArrayList<String> WordsArr=new ArrayList<>();
        ArrayList<String> posArr=new ArrayList<>();
        ArrayList<String> lemmaArr=new ArrayList<>();
        ArrayList<String> synoArr=new ArrayList<>();
        ArrayList<String> antoArr=new ArrayList<>();
        ArrayList<String> exampleArr=new ArrayList<>();
        ArrayList<String> defiArr=new ArrayList<>();

        for (int i=0;i<Records.size();i++){


                WordsArr.add(Records.get(i).getWord());
                posArr.add(Records.get(i).getPos());
                lemmaArr.add(Records.get(i).getLemma());
                synoArr.add(Records.get(i).getSyno());
                antoArr.add(Records.get(i).getAnto());
                exampleArr.add(Records.get(i).getExample());
                defiArr.add(Records.get(i).getDefinition());



            }


        /*ArrayList<Integer> DescTimeArr=new ArrayList<>();
        String[] DescTimeArrList=new String[TimesArr.size()];
        ArrayList<Integer> DescTimeArr_demo=new ArrayList<>();

        DescTimeArr_demo=TimesArr;
        Collections.sort(DescTimeArr_demo, Collections.reverseOrder());
        for (int descList=0; descList<DescTimeArr_demo.size(); descList++){
            if(!Arrays.asList(DescTimeArrList).equals(DescTimeArr_demo.get(descList)+"")){
              DescTimeArrList[descList]=DescTimeArr_demo.get(descList)+"";
                DescTimeArr.add(DescTimeArr_demo.get(descList));
                Log.d("descList","data : "+descList+" : "+DescTimeArr_demo.get(descList));

            }else {

                DescTimeArrList[descList]="null";
            }
        }*/
        //Collections.max(DescTimeArr,Collections.)
        //rowItems.add(new RowItem("Oh, what fun!", "আহা, কী মজা!"));
/**   public MyAdapter(Context context, word,pos,ArrayList<String> lemma, ArrayList<Integer> syno,  ArrayList<Integer> anto,  ArrayList<Integer> exmple,  ArrayList<Integer> defin, Activity activity1) */

        mAdapter = new WordDetailsActivity.MyAdapter
                      (this, WordsArr,posArr,lemmaArr,synoArr, antoArr,exampleArr,defiArr, WordDetailsActivity.this);
        recyclerView.setAdapter(mAdapter);

    }

    @Override
    public void onInit(int i) {

        if(i == TextToSpeech.SUCCESS){

            Log.d("woww","init is called");

            int result=tts.setLanguage(Locale.US);
            //  tts.setPitch(0.1f);
            tts.setSpeechRate(0.8f);
            //  int result=tts.setLanguage(new Locale("bn"));
            if(result==TextToSpeech.LANG_MISSING_DATA ||
                    result==TextToSpeech.LANG_NOT_SUPPORTED){
                Log.e("error", "This Language is not supported");
            }
            else{
                ConvertTextToSpeech(textforspeech);
            }
        }
        else
            Log.e("error", "Initilization Failed!");
    }


    public class MyAdapter extends RecyclerView.Adapter<WordDetailsActivity.MyAdapter.MyViewHolder> {
        private ArrayList<String> words;
        private ArrayList<String> pos;
        private ArrayList<String> lemma;
        private ArrayList<String> synonyms;
        private ArrayList<String> antonyms;
        private ArrayList<String> examples;
        private ArrayList<String> definitions;
        Context ctx;
        Activity activity;


        // Provide a reference to the views for each data item
        // Complex data items may need more than one view per item, and
        // you provide access to all the views for a data item in a view holder
        public class MyViewHolder extends RecyclerView.ViewHolder {
            // each data item is just a string in this case
            TextView tvword;
            TextView tvpos,lbpos;
            TextView tvlemma,lblemma;
            TextView tvsyno,tvanto,tvexample,tvdefinition;
            TextView lbsyno,lbanto,lbexample,lbdefinition;
            RelativeLayout rel_lay;

            public MyViewHolder(View itemView) {
                super(itemView);

                rel_lay = itemView.findViewById(R.id.conver_lay);
                tvword = itemView.findViewById(R.id.tvword);
                tvpos = itemView.findViewById(R.id.tvpos);
                lbpos = itemView.findViewById(R.id.label_pos);
                tvlemma = itemView.findViewById(R.id.tvlemma);
                lblemma = itemView.findViewById(R.id.label_lemma);
                tvsyno = itemView.findViewById(R.id.tvsynonyms);
                lbsyno = itemView.findViewById(R.id.label_syno);
                tvanto = itemView.findViewById(R.id.tvantonyms);
                lbanto = itemView.findViewById(R.id.label_anto);
                tvexample = itemView.findViewById(R.id.tvexample);
                lbexample = itemView.findViewById(R.id.label_example);
                tvdefinition = itemView.findViewById(R.id.tvdef);
                lbdefinition = itemView.findViewById(R.id.label_def);


            }
        }

        // Provide a suitable constructor (depends on the kind of dataset)
        public MyAdapter(Context context, ArrayList<String> word, ArrayList<String> pos,ArrayList<String> lemma, ArrayList<String> syno,  ArrayList<String> anto,  ArrayList<String> exmple,  ArrayList<String> defin, Activity activity1) {
            this.words=word;
            this.pos=pos;
            this.lemma=lemma;
            this.synonyms=syno;
            this.antonyms=anto;
            this.examples=exmple;
            this.definitions=defin;
            ctx = context;
            activity = activity1;

        }

        // Create new views (invoked by the layout manager)
        @Override
        public WordDetailsActivity.MyAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView;
            itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.row_item_word_details, parent, false);

            return new WordDetailsActivity.MyAdapter.MyViewHolder(itemView);

        }
        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(WordDetailsActivity.MyAdapter.MyViewHolder holder, final int position) {
            holder.tvword.setText(words.get(position));
            holder.tvpos.setText(pos.get(position));



            String lema=lemma.get(position);
            if(lema.length()>2) {
                holder.tvlemma.setVisibility(View.VISIBLE);
                holder.lblemma.setVisibility(View.VISIBLE);
                lema = lema.replace("[", "");
                lema = lema.replace("]", "");
                lema = lema.replace("'", "");
                lema = lema.replace("_", " ");
                if (lema.length() > 2) {
                    lema = Character.toUpperCase(lema.charAt(0)) + lema.substring(1);
                }
                holder.tvlemma.setText(lema);
            }else{
                holder.tvlemma.setVisibility(View.GONE);
                holder.lblemma.setVisibility(View.GONE);
            }


            String syno=synonyms.get(position);
            if(syno.length()>2) {
                holder.tvsyno.setVisibility(View.VISIBLE);
                holder.lbsyno.setVisibility(View.VISIBLE);
                syno = syno.replace("[", "");
                syno = syno.replace("]", "");
                syno = syno.replace("'", "");
                syno = syno.replace("_", " ");

                if (syno.length() > 2) {
                    syno = Character.toUpperCase(syno.charAt(0)) + syno.substring(1);
                }
                holder.tvsyno.setText(syno);

            }else{
                holder.tvsyno.setVisibility(View.GONE);
                holder.lbsyno.setVisibility(View.GONE);
            }


            String anto=antonyms.get(position);
            Log.d("antoo",position+" : "+antonyms.get(position) );
            if(anto.length()>2) {
                holder.tvanto.setVisibility(View.VISIBLE);
                holder.lbanto.setVisibility(View.VISIBLE);
                anto = anto.replace("[", "");
                anto = anto.replace("]", "");
                anto = anto.replace("'", "");
                anto = anto.replace("_", " ");
                if (anto.length() > 2) {
                    anto = Character.toUpperCase(anto.charAt(0)) + anto.substring(1);
                }
                holder.tvanto.setText(anto);
            }else{
                holder.tvanto.setVisibility(View.GONE);
                holder.lbanto.setVisibility(View.GONE);
            }

            String def=definitions.get(position);
            if(def.length()>2) {
                holder.tvdefinition.setVisibility(View.VISIBLE);
                holder.lbdefinition.setVisibility(View.VISIBLE);
                def = def.replace("[", "");
                def = def.replace("]", "");
                def = def.replace("'", "");
                def = def.replace("_", " ");
                if (def.length() > 2) {
                    def = Character.toUpperCase(def.charAt(0)) + def.substring(1);
                }
                holder.tvdefinition.setText(def);
            }else{
                holder.tvdefinition.setVisibility(View.GONE);
                holder.lbdefinition.setVisibility(View.GONE);
            }

            String exmp=examples.get(position);
            if(exmp.length()>2) {
                holder.tvexample.setVisibility(View.VISIBLE);
                holder.lbexample.setVisibility(View.VISIBLE);
                exmp = exmp.replace("[", "");
                exmp = exmp.replace("]", "");
                exmp = exmp.replace("'", "");
                exmp = exmp.replace("_", " ");

                if (exmp.length() > 2) {
                    exmp = Character.toUpperCase(exmp.charAt(0)) + exmp.substring(1);
                }
                holder.tvexample.setText(exmp);
            }else{
                holder.tvexample.setVisibility(View.GONE);
                holder.lbexample.setVisibility(View.GONE);
            }


            //holder.tvdefinition.setText(definitions.get(position));

            holder.rel_lay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   // textforspeech= rowItems.get(position).rword;
                    //textforspeech2= rowItems.get(position).rmeaning;
                    //ConvertTextToSpeech(rowItems.get(position).rword);

                }
            });




        }

        // Return the size of your dataset (invoked by the layout manager)
        @Override
        public int getItemCount() {
            return words.size();
        }


    }

    public int getElementThatContains(String[] ips, String key,int s) {
        for (int i = 0; i < s; i++) {
            if (ips[i].equals(key)) {
                return i;
            }
        }
        return -1;
    }
    private void ConvertTextToSpeech(String result) {

        // TODO Auto-generated method stub
        String text =result;
        //  tts.setOnUtteranceProgressListener(new TtsUtteranceListener());

        if(text==null||"".equals(text))
        {
//            text = "Content not available";
//            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
            map.clear();
        map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, new Random().nextInt(1000)+"");

        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onDone(String utteranceId) {
                Log.d("woww","ondone");
                ConvertTextToSpeech2(textforspeech2);
//                if(textforspeech2==null || textforspeech2.equals("")){
//                    Log.d("woww","texttospeech2 is null");
//
//                }else{
//                    Log.d("woww","texttospeech2 is NOT null");
//
//                    tts2.speak(textforspeech2, TextToSpeech.QUEUE_FLUSH, null);
//                    }

            }

            @Override
            public void onError(String utteranceId) {
                Log.d("woww","onError");
            }

            @Override
            public void onStart(String utteranceId) {
                Log.d("woww","onStart");
            }
        });


        tts.speak(text, TextToSpeech.QUEUE_FLUSH, map);

        //
    }
    private void ConvertTextToSpeech2(String result) {

        // TODO Auto-generated method stub
        String text =result;
        //  tts.setOnUtteranceProgressListener(new TtsUtteranceListener());

        if(text==null||"".equals(text))
        {
//            text = "Content not available";
//            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
//            map2.clear();
//            map2.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, new Random().nextInt(1000)+"");




            tts2.speak(text, TextToSpeech.QUEUE_FLUSH, null);

        //
    }


}
