package com.eclairios.englisher_pro.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.eclairios.englisher_pro.DataBaseHelper;
import com.eclairios.englisher_pro.R;
import com.eclairios.englisher_pro.adapter.HomeAdapter;
import com.eclairios.englisher_pro.model.Item;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements HomeAdapter.ItemListener{
    DataBaseHelper helper;

    private RecyclerView recyclerView;
    private ArrayList<Item> arrayList;
    ProgressBar progressBar;
    Handler handler = new Handler();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
        progressBar=findViewById(R.id.pbar);
        helper = new DataBaseHelper(this);

   //  progressBar.setVisibility(View.VISIBLE);
        handler = new Handler();


        //




        if (PreferenceManager.getDefaultSharedPreferences(MainActivity.this).getBoolean("once_login", true)){
            progressBar.setVisibility(View.VISIBLE);

            Toast.makeText(getApplicationContext(),"Fetching Lessons Data. Please Wait...",Toast.LENGTH_LONG).show();

            Runnable r = new Runnable() {
                public void run() {


                    helper.myFunc(MainActivity.this);
                    helper.myFunc2(MainActivity.this);



                    //
                    AlertDialog.Builder builderSingle = new AlertDialog.Builder(MainActivity.this);

            builderSingle.setTitle("Install offline dictionary");
            builderSingle.setMessage("Do you want to install offline dictionary?");

                    builderSingle.setPositiveButton("Install", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            progressBar.setVisibility(View.VISIBLE);

                            Runnable r = new Runnable() {
                                public void run() {

                                    progressBar.setVisibility(View.VISIBLE);

                                    helper.myFunc3(MainActivity.this);


                                    progressBar.setVisibility(View.INVISIBLE);


                                }
                            };
                            handler.postDelayed(r, 1000);

                        }
                    });

                    builderSingle.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });


            builderSingle.show();
                    //


                    PreferenceManager.getDefaultSharedPreferences(MainActivity.this).edit().putBoolean("once_login",false).apply();

                    progressBar.setVisibility(View.INVISIBLE);
                }
            };
            handler.postDelayed(r, 1000);


        }




        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        arrayList = new ArrayList<>();

        arrayList.add(new Item("English For Today (Class 6)", R.drawable.cover, "#09A9FF"));
//        arrayList.add(new Item("Item 2", R.drawable.cover, "#3E51B1"));
//        arrayList.add(new Item("Item 3", R.drawable.cover, "#673BB7"));
//        arrayList.add(new Item("Item 4", R.drawable.cover, "#4BAA50"));
//        arrayList.add(new Item("Item 5", R.drawable.cover, "#F94336"));
//        arrayList.add(new Item("Item 6", R.drawable.cover, "#0A9B88"));

        HomeAdapter adapter = new HomeAdapter(this, arrayList, this);
        recyclerView.setAdapter(adapter);


        /**
         AutoFitGridLayoutManager that auto fits the cells by the column width defined.
         **/

        //AutoFitGridLayoutManager layoutManager = new AutoFitGridLayoutManager(this, 500);
        //recyclerView.setLayoutManager(layoutManager);


        /**
         Simple GridLayoutManager that spans two columns
         **/
        GridLayoutManager manager = new GridLayoutManager(this, 2, GridLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(manager);
    }

    @Override
    public void onItemClick(Item item) {
       // Toast.makeText(getApplicationContext(), item.text + " is clicked", Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(this,LessonsActivity.class);
        startActivity(intent);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main_2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        //https://www.journaldev.com/13792/android-gridlayoutmanager-example
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_about_us) {

//            AlertDialog.Builder builderSingle = new AlertDialog.Builder(MainActivity.this);
//
//            builderSingle.setTitle("About us");
//            builderSingle.setMessage("This project is funded by ICT Division Bangladesh");
//
//            builderSingle.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//                @Override
//                public void onClick(DialogInterface dialog, int which) {
//                    dialog.dismiss();
//                }
//            });
//
//
//            builderSingle.show();

            startActivity(new Intent(this,AboutUs.class));

            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
