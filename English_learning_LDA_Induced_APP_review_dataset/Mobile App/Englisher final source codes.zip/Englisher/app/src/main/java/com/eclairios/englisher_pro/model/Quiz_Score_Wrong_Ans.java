package com.eclairios.englisher_pro.model;

public class Quiz_Score_Wrong_Ans {



    String QLessonNo;
    String Q_Millis;
    String Q_Score;
    String Q_Type;

    public String getWID() {
        return WID;
    }

    public void setWID(String WID) {
        this.WID = WID;
    }

    String WID;
    String WLessonNo;
    String W_Word;
    String W_Meaning;
    String W_Timestamp;


    public Quiz_Score_Wrong_Ans(){}
    public  Quiz_Score_Wrong_Ans(String id,String WLessonNo,String W_Word,String W_Meaning,String W_Timestamp){

        this.WID=id;
        this.WLessonNo=WLessonNo;
        this.W_Word=W_Word;
        this.W_Meaning=W_Meaning;
        this.W_Timestamp=W_Timestamp;
    }


    public String getQLessonNo() {
        return QLessonNo;
    }

    public void setQLessonNo(String QLessonNo) {
        this.QLessonNo = QLessonNo;
    }

    public String getQ_Millis() {
        return Q_Millis;
    }

    public void setQ_Millis(String q_Millis) {
        Q_Millis = q_Millis;
    }

    public String getQ_Score() {
        return Q_Score;
    }

    public void setQ_Score(String q_Score) {
        Q_Score = q_Score;
    }

    public String getQ_Type() {
        return Q_Type;
    }

    public void setQ_Type(String q_Type) {
        Q_Type = q_Type;
    }

    public String getWLessonNo() {
        return WLessonNo;
    }

    public void setWLessonNo(String WLessonNo) {
        this.WLessonNo = WLessonNo;
    }

    public String getW_Word() {
        return W_Word;
    }

    public void setW_Word(String w_Word) {
        W_Word = w_Word;
    }

    public String getW_Timestamp() {
        return W_Timestamp;
    }

    public void setW_Timestamp(String W_Timestampp) {
        W_Timestamp = W_Timestampp;
    }
    public String getW_Meaning() {
        return W_Meaning;
    }

    public void setW_Meaning(String w_Meaning) {
        W_Meaning = w_Meaning;
    }
}
