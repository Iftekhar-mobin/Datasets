package com.eclairios.englisher_pro.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.preference.PreferenceManager;
import android.support.v4.view.PagerAdapter;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.eclairios.englisher_pro.R;
import com.eclairios.englisher_pro.activity.DialogLessonActivity;
import com.eclairios.englisher_pro.activity.ListenActivity;
import com.eclairios.englisher_pro.activity.QuizActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;


/**
 * Created by khan on 1/11/2017.
 */

public class CustomSwipeAdapter extends PagerAdapter {


    ImageView btn_quiz;
    // ImageView img_speaker;
    CardView btn_lesson;
    TextView tx_lesson, tx_lesson_no;
    TextView tx_word, tx_meaning, tx_kanji;
    int[] status;

    String[] words_lst, meaning_list;
    ArrayList<String> ch_no_arr;
    ArrayList<Integer> ch_size_arr;
    String[] data;
    String[] data_ans;
    int[] data_index;
    private Context ctx;
    private LayoutInflater layoutInflater;

    public CustomSwipeAdapter(Context ctx, String[] words_lst, String[] meaning_list, ArrayList<String> ch_no_arr, ArrayList<Integer> ch_size_arr, int[] status) {
        this.ctx = ctx;
        this.words_lst = words_lst;
        this.meaning_list = meaning_list;
        this.ch_no_arr = ch_no_arr;
        this.ch_size_arr = ch_size_arr;
        this.status = status;

    }

    @Override
    public int getCount() {

        return words_lst.length;
    }


    @Override
    public boolean isViewFromObject(View view, Object object) {
        return (view == (LinearLayout) object);

    }

    @Override
    public Object instantiateItem(ViewGroup container, final int position) {
        layoutInflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View item_view = layoutInflater.inflate(R.layout.swipe_layout, container, false);
        //ImageView imageView=(ImageView)item_view.findViewById(R.id.imgDisplay);
        //imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        //imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        // imageView.setImageResource(image_resources[position]);
        /*item_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Arsalan","khan");
                Toast toast=Toast.makeText(this,"khan",Toast.LENGTH_LONG);

            }
        });
        */
        //textView.setText("DESIGN :"+position);


        /** &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */
        btn_lesson = item_view.findViewById(R.id.crd_lesson_btn);
        tx_lesson = item_view.findViewById(R.id.tx_lesson_no);
        tx_lesson_no = item_view.findViewById(R.id.tx_lesson_no_in_total);
        tx_word = item_view.findViewById(R.id.tx_lesson_word);
        tx_meaning = item_view.findViewById(R.id.tx_lesson_meaning);
        tx_kanji = item_view.findViewById(R.id.tx_lesson_kanji);
        btn_quiz = (ImageView) item_view.findViewById(R.id.quiz_btn);
        //img_speaker=item_view.findViewById(R.id.speaker_icon);

        /** &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */

        /**  IF THE USER NEED LESSON NO OF THE VOCABILARY THEN THIS FUNCTION  */
/*        for (int ix=0; ix<ch_no_arr.size(); ix++){
            int ch_ps=0;
            for (int i=0; i<ix; i++){
                ch_ps=ch_ps+ch_size_arr.get(i);
            }
            if (position<=ch_size_arr.get(ix)){
                tx_lesson.setText("Lesson "+ch_no_arr.get(ix));
                PreferenceManager.getDefaultSharedPreferences(ctx).edit().putString("chapter", ch_no_arr.get(ix)).apply();

                break;
            }

        }*/

            String chapters_no="";
            for (int i=0; i<ch_no_arr.size(); i++){
                if (i != 0)
                chapters_no=chapters_no+"-"+ch_no_arr.get(i);
                else
                    chapters_no=ch_no_arr.get(i);
            }


        tx_lesson.setText("Lesson \n" +chapters_no);
        /** &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */
        PreferenceManager.getDefaultSharedPreferences(ctx).edit().putInt("parctice_pos", position - 1).apply();
        int pos = PreferenceManager.getDefaultSharedPreferences(ctx).getInt("last_pos", 0);

        int currentpage = position + 1;
        tx_lesson_no.setText(currentpage + "/" + words_lst.length);
        tx_word.setText(words_lst[position]);
        tx_meaning.setText(meaning_list[position]);
        /** &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */
        boolean is_word_on = PreferenceManager.getDefaultSharedPreferences(ctx).getBoolean("isWord_on", false);
        boolean is_meaning_on = PreferenceManager.getDefaultSharedPreferences(ctx).getBoolean("isMeaning_on", false);

        if (is_word_on) {
            Log.d("aaa", "on_word");
            tx_word.setVisibility(View.VISIBLE);

        } else {
            tx_word.setVisibility(View.INVISIBLE);
            Log.d("aaa", "off_word");

        }
        if (is_meaning_on) {
            tx_meaning.setVisibility(View.VISIBLE);
            Log.d("aaa", "on_mean");

        } else {
            tx_meaning.setVisibility(View.INVISIBLE);
            Log.d("aaa", "off_mean");

        }
        /** &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */
        btn_lesson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ctx, DialogLessonActivity.class);
                intent.putExtra("status", status);
                // intent.setFlags()
                ctx.startActivity(intent);


            }
        });
        btn_quiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("tstng_rndm", "clicked");

                data = new String[10];
                data_ans = new String[10];
                data_index = new int[10];
                final int min = 1;
                final int max = meaning_list.length - 1;
                Log.d("tstng_rndm", "max : " + max);
                for (int i = 0; i < 10; i++) {
                    Log.d("tstng_rndm", "for loop : " + i);

                    boolean is_exists = true;


                    Log.d("tstng_rndm", "for loop : " + is_exists);
                    while (is_exists) {
                        Log.d("tstng_rndm", "while in for loop : " + is_exists);
                        final int random = new Random().nextInt((max - min) + 1) + min;

                        if (!Arrays.asList(data_index).contains(random)) {

                            data_index[i] = random;
                            data[i] = meaning_list[random];
                            data_ans[i] = words_lst[random];
                            Log.d("tstng_rndm", "word not exist in list : " + meaning_list[random]);
                            Log.d("tstng_rndm", "word  in list : " + data[i]);
                            Log.d("tstng_rndm", "word index in list : " + data_index[i]);
                            is_exists = false;
                        } else
                            Log.d("tstng_rndm", "word exist in list : " + meaning_list[random]);

                    }

                }

                new AlertDialog.Builder(ctx)
                        .setTitle("Selection")
                        .setMessage("Select Quiz type")

                        // Specifying a listener allows you to take an action before dismissing the dialog.
                        // The dialog is automatically dismissed when a dialog button is clicked.
                        .setPositiveButton("Reading Quiz", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Continue with delete operation

                                Intent intent = new Intent(ctx, QuizActivity.class);
                                intent.putExtra("data_arr", data);
                                intent.putExtra("data_ans_arr", data_ans);
                                intent.putExtra("data_index_arr", data_index);
                                intent.putExtra("all_ans_arr", words_lst);
                                //  Toast.makeText(ctx, ""+data.toString(), Toast.LENGTH_SHORT).show();
                                ctx.startActivity(intent);
                            }
                        })

                        // A null listener allows the button to dismiss the dialog and take no further action.
                        .setNeutralButton("Listening Quiz", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent(ctx, ListenActivity.class);
                                intent.putExtra("data_arr", data);
                                intent.putExtra("data_ans_arr", data_ans);
                                intent.putExtra("data_index_arr", data_index);
                                intent.putExtra("all_ans_arr", words_lst);
                                //  Toast.makeText(ctx, ""+data.toString(), Toast.LENGTH_SHORT).show();
                                ctx.startActivity(intent);
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();


            }
        });

    /*    img_speaker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
*/

        /** &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */
        container.addView(item_view);
        return item_view;

    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);

    }
}
