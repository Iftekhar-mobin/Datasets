package com.eclairios.englisher_pro.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import com.eclairios.englisher_pro.ClassVocabulory;
import com.eclairios.englisher_pro.DataBaseHelper;
import com.eclairios.englisher_pro.R;
import com.eclairios.englisher_pro.TopExceptionHandler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Random;


public class VocabularyActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {
    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    TextToSpeech tts;
    TextToSpeech tts2;
    String textforspeech;
    String textforspeech2;
    HashMap<String, String> map;
    HashMap<String, String> map2;




    ArrayList<VocabularyActivity.RowItem> rowItems = new ArrayList<VocabularyActivity.RowItem>();

   //  InterstitialAd mInterstitialAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Thread.setDefaultUncaughtExceptionHandler(new TopExceptionHandler(this));

        setContentView(R.layout.activity_vocabulary);
        String title = PreferenceManager.getDefaultSharedPreferences(this).getString("chapter", "null");



        setTitle("Vocabularies: Lesson "+title);

        map = new HashMap<String, String>();
        map2 = new HashMap<String, String>();

        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);

        tts=new TextToSpeech(this,this);
        tts2=new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {

                if(status == TextToSpeech.SUCCESS){

                    tts2.setSpeechRate(0.8f);
                      int result=tts2.setLanguage(new Locale("bn"));
                    if(result==TextToSpeech.LANG_MISSING_DATA ||
                            result==TextToSpeech.LANG_NOT_SUPPORTED){
                        Log.e("error", "This Language is not supported");
                    }
                    else{
                        ConvertTextToSpeech2(textforspeech2);
                    }
                }
                else
                    Log.e("error", "Initilization Failed!");
            }
        });


        /**
           AdView mAdView = findViewById(R.id.adView);
           AdRequest adRequest = new AdRequest.Builder().build();
           mAdView.loadAd(adRequest);
           MobileAds.initialize(this, getResources().getString(R.string.google_app_id));
           mInterstitialAd = new InterstitialAd(this);
           mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial_ad_unit_id));
           mInterstitialAd.loadAd(new AdRequest.Builder().build());
   */


        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);


//         use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);



/**     BackGroundTask task = new BackGroundTask(this, "https://soccer.sportmonks.com/api/v2.0/Books?include=leagues,sort=name&api_token=" + Constants.APIKEY, pBar);
        task.delegate = com.eclairios.englisher.activity.VocabularyActivity.this;
        task.executeTask(); */

        rowItems.clear();
        ArrayList<ClassVocabulory> Records = new ArrayList();
        DataBaseHelper dataBaseHelper=new DataBaseHelper(this);
        String chapter = PreferenceManager.getDefaultSharedPreferences(this).getString("chapter", "null");
        Records=dataBaseHelper.ShowVocabOneChapter(chapter);

        for (int i=0;i<Records.size();i++){
            rowItems.add(new RowItem(Records.get(i).getENGLISH(), Records.get(i).getBANGLA()));
        }

        //rowItems.add(new RowItem("Oh, what fun!", "আহা, কী মজা!"));

        mAdapter = new MyAdapter(this, rowItems, VocabularyActivity.this);
        recyclerView.setAdapter(mAdapter);

    }

    @Override
    public void onInit(int i) {

        if(i == TextToSpeech.SUCCESS){

            Log.d("woww","init is called");

            int result=tts.setLanguage(Locale.US);
          //  tts.setPitch(0.1f);
            tts.setSpeechRate(0.8f);
          //  int result=tts.setLanguage(new Locale("bn"));
            if(result==TextToSpeech.LANG_MISSING_DATA ||
                    result==TextToSpeech.LANG_NOT_SUPPORTED){
                Log.e("error", "This Language is not supported");
            }
            else{
                ConvertTextToSpeech(textforspeech);
            }
        }
        else
            Log.e("error", "Initilization Failed!");
    }


    public class MyAdapter extends RecyclerView.Adapter<VocabularyActivity.MyAdapter.MyViewHolder> {
        private ArrayList<VocabularyActivity.RowItem> rowItems;
        Context ctx;
        Activity activity;


        // Provide a reference to the views for each data item
        // Complex data items may need more than one view per item, and
        // you provide access to all the views for a data item in a view holder
        public class MyViewHolder extends RecyclerView.ViewHolder {
            // each data item is just a string in this case
            TextView tvword;
            TextView tvmeaning;
            ImageView ivspeak;
            ImageView ivdetails;

            public MyViewHolder(View itemView) {
                super(itemView);

                ivspeak = itemView.findViewById(R.id.row_img_speaker);
                ivdetails = itemView.findViewById(R.id.row_img_details);
                tvword = itemView.findViewById(R.id.ss_name);
                tvmeaning = itemView.findViewById(R.id.ss_meaning);


            }
        }

        // Provide a suitable constructor (depends on the kind of dataset)
        public MyAdapter(Context context, ArrayList<VocabularyActivity.RowItem> RowItems, Activity activity1) {
            rowItems = RowItems;
            ctx = context;
            activity = activity1;

        }

        // Create new views (invoked by the layout manager)
        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent,int viewType) {
            View itemView;
            itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.row_item_vocabulary, parent, false);

            return new VocabularyActivity.MyAdapter.MyViewHolder(itemView);

        }


        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(final VocabularyActivity.MyAdapter.MyViewHolder holder, final int position) {
            holder.tvword.setText(rowItems.get(position).rword.replace("\"",""));

            holder.tvmeaning.setText(rowItems.get(position).rmeaning.replace("\"",""));

            holder.ivspeak.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    holder.ivspeak.setImageDrawable(getResources().getDrawable(R.drawable.ic_play_arrow_black_24dp));

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            holder.ivspeak.setImageDrawable(getResources().getDrawable(R.drawable.speaker));


                        }
                    }, 2000);
                    textforspeech= rowItems.get(position).rword;
                    textforspeech2= rowItems.get(position).rmeaning;
                    ConvertTextToSpeech(rowItems.get(position).rword);

                }
            });

            holder.ivdetails.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    String url = "https://translate.google.com/?hl=bn#view=home&op=translate&sl=en&tl=bn&text="+rowItems.get(position).rword;
//                    Intent i = new Intent(Intent.ACTION_VIEW);
//                    i.setData(Uri.parse(url));

                   Intent i=new Intent(getApplicationContext(),WordDetailsActivity.class);
                   i.putExtra("word",rowItems.get(position).rword);
                    startActivity(i);
                }
            });


        }

        // Return the size of your dataset (invoked by the layout manager)
        @Override
        public int getItemCount() {
            return rowItems.size();
        }


    }


    class RowItem {
        String rword;
        String rmeaning;

        RowItem(String RWord, String RMeaning) {
            rword = RWord;
            rmeaning = RMeaning;
        }


    }
    private void ConvertTextToSpeech(String result) {

        // TODO Auto-generated method stub
        String text =result;
      //  tts.setOnUtteranceProgressListener(new TtsUtteranceListener());

        if(text==null||"".equals(text))
        {
//            text = "Content not available";
//            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
            map.clear();
            map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, new Random().nextInt(1000)+"");

            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onDone(String utteranceId) {
               Log.d("woww","ondone");
                ConvertTextToSpeech2(textforspeech2);
//                if(textforspeech2==null || textforspeech2.equals("")){
//                    Log.d("woww","texttospeech2 is null");
//
//                }else{
//                    Log.d("woww","texttospeech2 is NOT null");
//
//                    tts2.speak(textforspeech2, TextToSpeech.QUEUE_FLUSH, null);
//                    }

            }

            @Override
            public void onError(String utteranceId) {
                Log.d("woww","onError");
            }

            @Override
            public void onStart(String utteranceId) {
                Log.d("woww","onStart");
            }
        });


            tts.speak(text, TextToSpeech.QUEUE_FLUSH, map);

        //
    }
    private void ConvertTextToSpeech2(String result) {

        // TODO Auto-generated method stub
        String text =result;
      //  tts.setOnUtteranceProgressListener(new TtsUtteranceListener());

        if(text==null||"".equals(text))
        {
//            text = "Content not available";
//            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
//            map2.clear();
//            map2.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, new Random().nextInt(1000)+"");




            tts2.speak(text, TextToSpeech.QUEUE_FLUSH, null);

        //
    }

}
