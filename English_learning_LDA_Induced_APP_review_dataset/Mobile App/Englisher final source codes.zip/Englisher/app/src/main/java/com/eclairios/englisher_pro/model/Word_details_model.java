package com.eclairios.englisher_pro.model;

public class Word_details_model {



    String Word;
    String Pos,Lemma;
    String Syno;
    String Anto;
String Example,Definition;


    public Word_details_model(){}

    public Word_details_model(String word, String pos, String lemma, String syno, String anto, String example, String definition) {
        Word = word;
        Pos = pos;
        Lemma = lemma;
        Syno = syno;
        Anto = anto;
        Example = example;
        Definition = definition;
    }

    public String getWord() {
        return Word;
    }

    public void setWord(String word) {
        Word = word;
    }

    public String getPos() {
        return Pos;
    }

    public void setPos(String pos) {
        Pos = pos;
    }

    public String getLemma() {
        return Lemma;
    }

    public void setLemma(String lemma) {
        Lemma = lemma;
    }

    public String getSyno() {
        return Syno;
    }

    public void setSyno(String syno) {
        Syno = syno;
    }

    public String getAnto() {
        return Anto;
    }

    public void setAnto(String anto) {
        Anto = anto;
    }

    public String getExample() {
        return Example;
    }

    public void setExample(String example) {
        Example = example;
    }

    public String getDefinition() {
        return Definition;
    }

    public void setDefinition(String definition) {
        Definition = definition;
    }
}
