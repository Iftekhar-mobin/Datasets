package com.eclairios.englisher_pro.adapter;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.eclairios.englisher_pro.R;
import com.eclairios.englisher_pro.activity.WrongAnsActivity;

import java.util.ArrayList;

public class CustomDialogClass extends Dialog implements
        android.view.View.OnClickListener {

    public Activity c;
    public Dialog d;
    public Button yes, no,bthistory;
    ArrayList Correctwords,Wrongwords;
    TextView tx_rgt,tx_wrng, tvright,tvwrong;

    String right;


    public CustomDialogClass(Activity a,String right,ArrayList Corrected,ArrayList Mistaken) {
        super(a);
        // TODO Auto-generated constructor stub
        this.c = a;
        this.Correctwords=Corrected;
        this.Wrongwords=Mistaken;
        this.right=right;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.custom_dialog_box);
        yes = (Button) findViewById(R.id.btn_yes);
        tx_rgt =  findViewById(R.id.txt_correct);
        tx_wrng =  findViewById(R.id.txt_wrong);
        tvright =  findViewById(R.id.tvcorrect);
        tvwrong =  findViewById(R.id.tvwrong);
        bthistory=findViewById(R.id.btn_history);
        yes.setOnClickListener(this);

        int wr=10-Integer.parseInt(right);
        tx_rgt.setText("Correct\n"+right);
        tx_wrng.setText("Wrong\n"+wr);
        tvright.setText("Corrected:");
        tvwrong.setText("Mistaken:");
        for (int i=0; i<Correctwords.size();i++){
            tvright.setText(tvright.getText().toString()+"\n"+(i+1)+". "+Correctwords.get(i));
        }

        for (int i=0; i<Wrongwords.size();i++){
            tvwrong.setText(tvwrong.getText().toString()+"\n"+(i+1)+". "+Wrongwords.get(i));
        }

        bthistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(c, WrongAnsActivity.class);
                c.startActivity(intent);
            }
        });


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_yes:
                c.finish();
                break;

            default:
                break;
        }
        dismiss();
    }
}