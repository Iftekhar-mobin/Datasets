package com.eclairios.englisher_pro.model;



public class LessonsItem {

    public String text;
    public String header;
    public String color;

    public LessonsItem(String text, String header, String color ) {
        this.text = text;
        this.header = header;
        this.color = color;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getDrawable() {
        return header;
    }

    public void setDrawable(int drawable) {
        this.header = header;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
