package com.eclairios.englisher_pro;



public class ClassDictionary {

    String ID;
    String WORD;
    String POS;
    String LEMMA;
    String SYNONYMS;
    String ANTONYMS;
    String EXAMPLE;
    String DEFINITION;

    public ClassDictionary(String ID, String WORD, String POS, String LEMMA, String SYNONYMS, String ANTONYMS, String EXAMPLE, String DEFINITION) {
        this.ID = ID;
        this.WORD = WORD;
        this.POS = POS;
        this.LEMMA = LEMMA;
        this.SYNONYMS = SYNONYMS;
        this.ANTONYMS = ANTONYMS;
        this.EXAMPLE = EXAMPLE;
        this.DEFINITION = DEFINITION;
    }
public ClassDictionary(){}

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getWORD() {
        return WORD;
    }

    public void setWORD(String WORD) {
        this.WORD = WORD;
    }

    public String getPOS() {
        return POS;
    }

    public void setPOS(String POS) {
        this.POS = POS;
    }

    public String getLEMMA() {
        return LEMMA;
    }

    public void setLEMMA(String LEMMA) {
        this.LEMMA = LEMMA;
    }

    public String getSYNONYMS() {
        return SYNONYMS;
    }

    public void setSYNONYMS(String SYNONYMS) {
        this.SYNONYMS = SYNONYMS;
    }

    public String getANTONYMS() {
        return ANTONYMS;
    }

    public void setANTONYMS(String ANTONYMS) {
        this.ANTONYMS = ANTONYMS;
    }

    public String getEXAMPLE() {
        return EXAMPLE;
    }

    public void setEXAMPLE(String EXAMPLE) {
        this.EXAMPLE = EXAMPLE;
    }

    public String getDEFINITION() {
        return DEFINITION;
    }

    public void setDEFINITION(String DEFINITION) {
        this.DEFINITION = DEFINITION;
    }
}
