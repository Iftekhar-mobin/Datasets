package com.eclairios.englisher_pro.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.eclairios.englisher_pro.ClassVocabulory;
import com.eclairios.englisher_pro.DataBaseHelper;
import com.eclairios.englisher_pro.R;
import java.util.ArrayList;
import java.util.Random;

public class MenuActivity extends AppCompatActivity {
    TextView tv_title;
    RelativeLayout rsentences, rvocabolary, rpractice, rconversation, rquiz,rhistory;
    DataBaseHelper helper;
ArrayList <Integer> indexes=new ArrayList<>();
    ArrayList<Integer> chapter_size;
    ArrayList<String> chapter;
    ArrayList<ClassVocabulory> Records = new ArrayList();
    String[] meaning_lst, words_lst;
    String[] data, data_ans;
    int[] data_index;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Initialization();
        ClickListeners(this);
//
//        mAdView = findViewById(R.id.adView);
//        AdRequest adRequest = new AdRequest.Builder().build();
//        mAdView.loadAd(adRequest);

        //  String title   = getPreferences(MODE_PRIVATE).getString("title","not found");
        String title = PreferenceManager.getDefaultSharedPreferences(this).getString("chapter", "null");
        // title=getIntent().getStringExtra("chapter");
        tv_title.setText("Lesson " + title);

        getQuizData();


    }

    private void getQuizData() {
        String chapterx = PreferenceManager.getDefaultSharedPreferences(this).getString("chapter", "null");
        Records = helper.ShowVocabOneChapter(chapterx);
        chapter_size.add(Records.size());
        chapter.add(chapterx);
        words_lst = new String[Records.size()];
        meaning_lst = new String[Records.size()];
        for (int i = 0; i < Records.size(); i++) {

            words_lst[i] = Records.get(i).getENGLISH();
            meaning_lst[i] = Records.get(i).getBANGLA();

        }

    }

    private void ClickListeners(final Context context) {
        rvocabolary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = PreferenceManager.getDefaultSharedPreferences(context).getString("chapter", "null");
                Intent intent = new Intent(context, VocabularyActivity.class);
                intent.putExtra("chapter", title);
                startActivity(intent);

            }
        });
        rpractice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PreferenceManager.getDefaultSharedPreferences(MenuActivity.this).edit().putBoolean("isWord_on", true).apply();
                PreferenceManager.getDefaultSharedPreferences(MenuActivity.this).edit().putBoolean("isMeaning_on", true).apply();
                PreferenceManager.getDefaultSharedPreferences(MenuActivity.this).edit().putInt("last_pos", -1).apply();
                String title = PreferenceManager.getDefaultSharedPreferences(context).getString("chapter", "null");
                Intent intent = new Intent(context, ParcticeActivity.class);
                intent.putExtra("chapter", title);
                startActivity(intent);

            }
        });
        rsentences.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = PreferenceManager.getDefaultSharedPreferences(context).getString("chapter", "null");
                Intent intent = new Intent(context, SentanceActivity.class);
                intent.putExtra("chapter", title);
                startActivity(intent);

            }
        });
        rconversation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = PreferenceManager.getDefaultSharedPreferences(context).getString("chapter", "null");
                Intent intent = new Intent(context, ConversationActivity.class);
                intent.putExtra("chapter", title);
                startActivity(intent);

            }
        });
        rquiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = PreferenceManager.getDefaultSharedPreferences(context).getString("chapter", "null");
              /*  Intent intent=new Intent(context, ConversationActivity.class);
                intent.putExtra("chapter",title);
                startActivity(intent);*/


                Log.d("tstng_rndm", "clicked");

                data = new String[10];
                data_ans = new String[10];
                data_index = new int[10];
                final int min = 1;
                final int max = meaning_lst.length - 1;
                for(int i=0;i<words_lst.length;i++){
                    Log.d("eee "+i,words_lst[i]);
                }
                Log.d("tstng_rndm", "max : " + max);
                for (int i = 0; i < 10; i++) {
                    Log.d("tstng_rndm", "for loop : " + i);

                    boolean is_exists = true;


                    Log.d("tstng_rndm", "for loop : " + is_exists);
                    while (is_exists) {
                        Log.d("tstng_rndm", "while in for loop : " + is_exists);
                   //     final int random = new Random().nextInt((max - min) + 1) + min;
                        final int random = new Random().nextInt(max ) ;
                        boolean valid=   Validate(random);
                       // if (!Arrays.asList(data_index).contains(random)) {
                        if (valid || words_lst.length<10) {



                            Log.d("tstng_rndm", "word index tesging : " + data_index[i]+" :: "+valid);


                            data_index[i] = random;
                            data[i] = meaning_lst[random];
                            data_ans[i] = words_lst[random];
                            Log.d("tstng_rndm", "word not exist in list : " + words_lst[random]);
                            Log.d("tstng_rndm", "word  in list : " + data[i]);
                            Log.d("tstng_rndm", "word index in list : " + data_index[i]);
                            is_exists = false;
                        } else
                            Log.d("tstng_rndm", "word exist in list : " + meaning_lst[random]);

                    }

                }
/*
                new AlertDialog.Builder(MenuActivity.this)
                        .setTitle("Select Quiz type")


                        // Specifying a listener allows you to take an action before dismissing the dialog.
                        // The dialog is automatically dismissed when a dialog button is clicked.
                        .setPositiveButton("Reading Quiz", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Continue with delete operation

                                Intent intent = new Intent(MenuActivity.this, QuizActivity.class);
                                intent.putExtra("data_arr", data);
                                intent.putExtra("data_ans_arr", data_ans);
                                intent.putExtra("data_index_arr", data_index);
                                intent.putExtra("all_ans_arr", words_lst);
                                //  Toast.makeText(ctx, ""+data.toString(), Toast.LENGTH_SHORT).show();
                                startActivity(intent);
                            }
                        })

                        // A null listener allows the button to dismiss the dialog and take no further action.
                        .setNeutralButton("Listening Quiz", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent(MenuActivity.this, ListenActivity.class);
                                intent.putExtra("data_arr", data);
                                intent.putExtra("data_ans_arr", data_ans);
                                intent.putExtra("data_index_arr", data_index);
                                intent.putExtra("all_ans_arr", words_lst);
                                //  Toast.makeText(ctx, ""+data.toString(), Toast.LENGTH_SHORT).show();
                                startActivity(intent);
                            }
                        })
                        .show();*/

                AlertDialog.Builder builderSingle = new AlertDialog.Builder(MenuActivity.this);

                builderSingle.setTitle("Select Quiz type");

                final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(MenuActivity.this, android.R.layout.simple_list_item_1);

                arrayAdapter.add("Reading Quiz");
                arrayAdapter.add("Listening Quiz");

                builderSingle.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                builderSingle.setAdapter(arrayAdapter, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String strName = arrayAdapter.getItem(which);
                       if (strName.contains("Reading Quiz")){
                           Intent intent = new Intent(MenuActivity.this, QuizActivity.class);
                           intent.putExtra("data_arr", data);
                           intent.putExtra("data_ans_arr", data_ans);
                           intent.putExtra("data_index_arr", data_index);
                           intent.putExtra("all_ans_arr", words_lst);
                           indexes.clear();
                           //  Toast.makeText(ctx, ""+data.toString(), Toast.LENGTH_SHORT).show();
                           startActivity(intent);
                       }else {
                           Intent intent = new Intent(MenuActivity.this, ListenActivity.class);
                           intent.putExtra("data_arr", data);
                           intent.putExtra("data_ans_arr", data_ans);
                           intent.putExtra("data_index_arr", data_index);
                           intent.putExtra("all_ans_arr", words_lst);
                           indexes.clear();

                           //  Toast.makeText(ctx, ""+data.toString(), Toast.LENGTH_SHORT).show();
                           startActivity(intent);
                       }
                    }
                });
                builderSingle.show();


            }
        });

        rhistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = PreferenceManager.getDefaultSharedPreferences(context).getString("chapter", "null");
                Intent intent = new Intent(context, WrongAnsActivity.class);

                startActivity(intent);

            }
        });

    }

    private boolean Validate(int random) {
        if(indexes.size()==0) {
            indexes.add(random);
            return true;
        }
            for (int i = 0; i < indexes.size();i++){
                if (indexes.get(i)==(random)){
                    return false;
                }

            }
        indexes.add(random);
        return true;

    }


    private void Initialization() {
        tv_title = findViewById(R.id.title);

        rsentences = findViewById(R.id.rl1);
        rvocabolary = findViewById(R.id.rl2);
        rpractice = findViewById(R.id.rl3);
        rconversation = findViewById(R.id.rl4);
        rquiz = findViewById(R.id.rl5);
        rhistory = findViewById(R.id.rl6);


        chapter = new ArrayList<>();
        chapter_size = new ArrayList<>();
        helper = new DataBaseHelper(MenuActivity.this);


    }
}
