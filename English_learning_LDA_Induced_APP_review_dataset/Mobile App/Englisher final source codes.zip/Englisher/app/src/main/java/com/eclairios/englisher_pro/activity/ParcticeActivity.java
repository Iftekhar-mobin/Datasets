package com.eclairios.englisher_pro.activity;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.eclairios.englisher_pro.ClassVocabulory;
import com.eclairios.englisher_pro.DataBaseHelper;
import com.eclairios.englisher_pro.R;
import com.eclairios.englisher_pro.adapter.CustomSwipeAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Random;

public class ParcticeActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    ArrayList<Integer> arr_lessons;

    //MediaPlayer mp;
    private final static int MAX_VOLUME = 100;
    TextToSpeech tts;
    TextToSpeech tts2;
    CheckBox cbox_word,cbox_meaning,cbox_kanji;
    ImageView speaker_img;
TextView tx_meaning;
  //  private  int[] vea={R.raw.car_wheeel};
    //voel  vlinder vlakvark
    private String[] words_lst={"aap","beer","cheetah","dolfyn","gorrilla","luiperd","zebra"};
    private String[] meaning_lst={"bandar","Beer","Cheetah","mahiii","shado","az","zebra"};
    private String[] kanji_lst;
    int[] status={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

    ArrayList<String> chapter;
    ArrayList<Integer> chapter_size;

    HashMap<String, String> map;
    HashMap<String, String> map2;

    String textforspeech;
    String textforspeech2;
    Button next,prev;
    int a;
    public static final String mehndi_image_position = "noteimage";
    public static final int DETAIL_REQUEST_CODE = 1001;
    MediaPlayer mediaPlayer=null;
    Button zoom;
    ImageButton sound;
    ViewPager viewPager;
    CustomSwipeAdapter adapter;
    boolean isFromList=false;
    public static int[]   image_resources = {R.drawable.arrow_down,R.drawable.sound_ic,R.drawable.arrow_down};



    ArrayList<ParcticeActivity.RowItem> rowItems = new ArrayList<ParcticeActivity.RowItem>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parctice);

//tx_meaning=findViewById(R.id.)



        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//keep screen on
/*
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.hide();


        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);*/

        //     next=(Button)findViewById(R.id.button2);
        //    prev=(Button)findViewById(R.id.button3);

        arr_lessons=new ArrayList<>();
        chapter=new ArrayList<>();
        chapter_size=new ArrayList<>();
        map = new HashMap<String, String>();
        map2 = new HashMap<String, String>();
        cbox_word=findViewById(R.id.cb_word);
        cbox_meaning=findViewById(R.id.cb_meaning);
        cbox_kanji=findViewById(R.id.cb_kanji);
        speaker_img=findViewById(R.id.speaker_icon);


        viewPager=(ViewPager)findViewById(R.id.view_pager);


        /** &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */
        Intent intent=getIntent();



        Log.d("tstng_array","on Create : ");
        rowItems.clear();
        ArrayList<ClassVocabulory> Records = new ArrayList();
        DataBaseHelper dataBaseHelper=new DataBaseHelper(this);

        boolean is_meaning_on=PreferenceManager.getDefaultSharedPreferences(ParcticeActivity.this).getBoolean("isMeaning_on", false);

        if (!is_meaning_on)
            cbox_meaning.setChecked(false);

        try{
            if (intent.getStringExtra("from_list").equals("ok"))
                isFromList =true;

        }catch (NullPointerException e){e.printStackTrace();}

        Log.d("tstng_array","is from list : "+isFromList);
        if (isFromList){

            chapter=intent.getStringArrayListExtra("chapter_no_arr");

            chapter_size=new ArrayList<>();

            Log.d("tstng_array","list size : "+chapter.size());
            for (int i=0; i<chapter.size(); i++){

                Log.d("tstng_array","list size : "+chapter.get(i));
                int chpos=Integer.parseInt(chapter.get(i))-1;
                status[chpos]=1;
                ArrayList<ClassVocabulory> Records_single = new ArrayList();
                Records_single = dataBaseHelper.ShowVocabOneChapter(chapter.get(i));


                Log.d("tstng_array","chapter size : "+Records_single.size());
                chapter_size.add(Records_single.size());
                for (int xy=0; xy<Records_single.size(); xy++){
                    Records.add(Records_single.get(xy));
                }
                Log.d("tstng_array","record size : "+Records.size());
            }

        }else {
            String chapterx = PreferenceManager.getDefaultSharedPreferences(this).getString("chapter", "null");

            int pos=Integer.parseInt(chapterx)-1;
            status[pos]=1;
            chapter.add(chapterx);
            Records = dataBaseHelper.ShowVocabOneChapter(chapterx);
            chapter_size.add(Records.size());
        }
        tts=new TextToSpeech(this,this);
        tts2=new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {

                if(status == TextToSpeech.SUCCESS){

                    tts2.setSpeechRate(0.8f);
                    int result=tts2.setLanguage(new Locale("bn"));
                    if(result==TextToSpeech.LANG_MISSING_DATA ||
                            result==TextToSpeech.LANG_NOT_SUPPORTED){
                        Log.e("error", "This Language is not supported");
                    }
                    else{
                        ConvertTextToSpeech2(textforspeech2);
                    }
                }
                else
                    Log.e("error", "Initilization Failed!");
            }
        });


        words_lst=new String[Records.size()];
        meaning_lst=new String[Records.size()];
        for (int i=0;i<Records.size();i++){
            rowItems.add(new ParcticeActivity.RowItem(Records.get(i).getENGLISH(), Records.get(i).getBANGLA()));

            words_lst[i]=Records.get(i).getENGLISH();
            meaning_lst[i]=Records.get(i).getBANGLA();

        }

        //rowItems.add(new RowItem("Oh, what fun!", "আহা, কী মজা!"));

        Log.d("tstng_array","Chapter no : "+chapter.toString());
        Log.d("tstng_array","Chapter size : "+chapter_size.toString());
        adapter=new CustomSwipeAdapter(this,words_lst,meaning_lst,chapter,chapter_size,status);
        viewPager.setAdapter(adapter);

        /** &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */
        speaker_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                speaker_img.setImageDrawable(getResources().getDrawable(R.drawable.ic_play_arrow_black_24dp));

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        speaker_img.setImageDrawable(getResources().getDrawable(R.drawable.speaker));


                    }
                }, 2600);
                int currentPos=PreferenceManager.getDefaultSharedPreferences(ParcticeActivity.this).getInt("parctice_pos", 0);
                boolean is_word_on=PreferenceManager.getDefaultSharedPreferences(ParcticeActivity.this).getBoolean("isWord_on", false);
                boolean is_meaning_on=PreferenceManager.getDefaultSharedPreferences(ParcticeActivity.this).getBoolean("isMeaning_on", false);

                if (is_word_on && is_meaning_on){

                    textforspeech=words_lst[currentPos];
                    textforspeech2=meaning_lst[currentPos];
                    ConvertTextToSpeech(words_lst[currentPos]);
                }else {
                    if (!is_word_on){
                        ConvertTextToSpeech2(meaning_lst[currentPos]);
                    }
                    if (!is_meaning_on){
                        ConvertTextToSpeech(words_lst[currentPos]);
                    }
                }
            }
        });
        cbox_word.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    PreferenceManager.getDefaultSharedPreferences(ParcticeActivity.this).edit().putBoolean("isWord_on", true).apply();
                    // tx_word.setVisibility(View.VISIBLE);
                    Log.d("tstng_cbox","word checked");
                }
                else{
                    PreferenceManager.getDefaultSharedPreferences(ParcticeActivity.this).edit().putBoolean("isWord_on", false).apply();
                    // tx_word.setVisibility(View.INVISIBLE);
                    Log.d("tstng_cbox","word not checked");
                }
            }
        });
        cbox_meaning.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    PreferenceManager.getDefaultSharedPreferences(ParcticeActivity.this).edit().putBoolean("isMeaning_on", true).apply();
                    // tx_meaning.setVisibility(View.VISIBLE);
                    Log.d("tstng_cbox","meaning checked");
                }
                else{
                    Log.d("tstng_cbox","meaning not checked");
                    PreferenceManager.getDefaultSharedPreferences(ParcticeActivity.this).edit().putBoolean("isMeaning_on", false).apply();
                    // tx_meaning.setVisibility(View.INVISIBLE);
                }int currentPos=PreferenceManager.getDefaultSharedPreferences(ParcticeActivity.this).getInt("parctice_pos", 0);

                PreferenceManager.getDefaultSharedPreferences(ParcticeActivity.this).edit().putInt("last_pos", currentPos).apply();


                /** */
                Intent refresh = new Intent(ParcticeActivity.this, ParcticeActivity.class);

                if (isFromList){

                    refresh.putExtra("from_list","ok");
                    refresh.putStringArrayListExtra("chapter_no_arr",chapter);
                   // refresh.putExtra("chapter_status_arr",resultStatus);

                }
                startActivity(refresh);
                finish();
            }
        });


        /** &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& */

        int maxVolume = 50;

        final float volume = (float) (1 - (Math.log(MAX_VOLUME - 80) / Math.log(MAX_VOLUME)));
//        mp.setVolume(volume, volume);

//        float log1=(float)(Math.log(maxVolume-currVolume)/Math.log(maxVolume));
//        mp.setVolume(1-log1,1-log1);
        //mp.setLooping(true);

      //  mp.start();



        //AddLastScreen()

        //   zoom=(Button)findViewById(R.id.button);
  /*      prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currentItem = viewPager.getCurrentItem();
                viewPager.setCurrentItem(currentItem+1);
            }
        });*/
     /*   next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currentItem = viewPager.getCurrentItem();
                viewPager.setCurrentItem(currentItem-1);
            }
        });*/


        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                Log.d("kkkkmkkkk","onpscrolled: "+position+" : "+positionOffset+" : "+positionOffsetPixels);
                int pos = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getInt("last_pos", -1);

                if (pos!= -1){

                    viewPager.setCurrentItem(pos);

                    PreferenceManager.getDefaultSharedPreferences(ParcticeActivity.this).edit().putInt("last_pos", -1).apply();

                }
            }

            @Override
            public void onPageSelected(int position) {
                a=position;
                Log.d("kkkkmkkkk","onPageSelected: "+position+" : ");
                boolean is_word_on = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getBoolean("isWord_on", false);
                boolean is_meaning_on = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getBoolean("isMeaning_on", false);
                int pos = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getInt("last_pos", 0);

/*
                if (is_meaning_on) {
                 //   tx_meaning.setVisibility(View.VISIBLE);
                    Log.d("aaa", "on_mean");

                } else {
                    meaning_lst[position]="";
                    adapter.notifyDataSetChanged();

                 //   tx_meaning.setVisibility(View.INVISIBLE);
                    Log.d("aaa", "off_mean");

                }*/
                Toast toast=Toast.makeText(getApplicationContext(),"arsalan"+a,Toast.LENGTH_SHORT);
                // toast.show();
                // int c=image_resources[position];
                // Log.i("arsalan","position: "+a+"image : "+c);

           //     mediaPlayer = MediaPlayer.create(getApplicationContext(), audio_resources[position]);

                //mediaPlayer.start();
                if(position==53){

                    // Log.i("arsalan","ending: "+a+"image : "+c);

//                    Intent intent=new Intent(MainActivity.this,Exit.class);
//                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                    startActivityForResult(intent,999);
                }
             //   MediaPlayer mp2 = MediaPlayer.create(getApplicationContext(), R.raw.cliksound);
            //    mp2.start();



            }

            @Override
            public void onPageScrollStateChanged(int state) {
                Log.i("arsalan","onpagescrolled: "+state);

            }
        });



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if(requestCode==999 && resultCode== Activity.RESULT_OK){
            String str=  data.getStringExtra("str");
            //   Toast.makeText(this,"returned",Toast.LENGTH_LONG).show();
            if(str.equals("exit")){}
            finish();
        }
    }

/*    private void AddLastScreen() {
      int length=  image_resources.length;
        length++;
        image_resources[length]= {R.drawable.aap};
    }*/

    @Override
    protected void onPause() {
        /*if(mp!=null){
            mp.stop();
            mp.release();
            mp=null;
        }*/
        super.onPause();
    }


    @Override
    public void onInit(int i) {

        if(i == TextToSpeech.SUCCESS){

            Log.d("woww","init is called");

            int result=tts.setLanguage(Locale.US);
            //  tts.setPitch(0.1f);
            tts.setSpeechRate(0.8f);
            //  int result=tts.setLanguage(new Locale("bn"));
            if(result==TextToSpeech.LANG_MISSING_DATA ||
                    result==TextToSpeech.LANG_NOT_SUPPORTED){
                Log.e("error", "This Language is not supported");
            }
            else{
                ConvertTextToSpeech(textforspeech);
            }
        }
        else
            Log.e("error", "Initilization Failed!");
    }


    private void ConvertTextToSpeech(String result) {

        // TODO Auto-generated method stub
        String text =result;
        //  tts.setOnUtteranceProgressListener(new TtsUtteranceListener());

        if(text==null||"".equals(text))
        {
//            text = "Content not available";
//            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
            map.clear();
        map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, new Random().nextInt(1000)+"");

        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onDone(String utteranceId) {
                Log.d("woww","ondone");
                boolean is_meaning_on=PreferenceManager.getDefaultSharedPreferences(ParcticeActivity.this).getBoolean("isMeaning_on", false);
                if(is_meaning_on) {
                    ConvertTextToSpeech2(textforspeech2);
                }
//                if(textforspeech2==null || textforspeech2.equals("")){
//                    Log.d("woww","texttospeech2 is null");
//
//                }else{
//                    Log.d("woww","texttospeech2 is NOT null");
//
//                    tts2.speak(textforspeech2, TextToSpeech.QUEUE_FLUSH, null);
//                    }

            }

            @Override
            public void onError(String utteranceId) {
                Log.d("woww","onError");
            }

            @Override
            public void onStart(String utteranceId) {
                Log.d("woww","onStart");
            }
        });


        tts.speak(text, TextToSpeech.QUEUE_FLUSH, map);

        //
    }

    private void ConvertTextToSpeech2(String result) {

        // TODO Auto-generated method stub
        String text =result;
        //  tts.setOnUtteranceProgressListener(new TtsUtteranceListener());

        if(text==null||"".equals(text))
        {
//            text = "Content not available";
//            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
//            map2.clear();
//            map2.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, new Random().nextInt(1000)+"");




            tts2.speak(text, TextToSpeech.QUEUE_FLUSH, null);

        //
    }
    class RowItem {
        String rword;
        String rmeaning;

        RowItem(String RWord, String RMeaning) {
            rword = RWord;
            rmeaning = RMeaning;
        }


    }

}
