package com.eclairios.englisher_pro;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.RequestBody;

public class BackGroundTask {


    public AsyncResponse delegate = null;
    RequestBody requestBody;
    ProgressBar pBar;
    Context ctx;
    String urlx;
    boolean isPost = false;
    boolean is_pBar=true;

    BackGroundTask(Context ctx, String urlx, ProgressBar pBar) {

        this.ctx = ctx;
        this.urlx = urlx;
        this.pBar = pBar;
        isPost = false;

    }
    BackGroundTask(Context ctx, String urlx, ProgressBar pBar, RequestBody requestBody) {

        this.ctx = ctx;
        this.urlx = urlx;
        this.pBar = pBar;
        this.requestBody = requestBody;
        isPost = true;


    }
 BackGroundTask(Context ctx, String urlx, RequestBody requestBody) {

        this.ctx = ctx;
        this.urlx = urlx;
      is_pBar=false;
        this.requestBody = requestBody;
        isPost = true;


    }

    public BackGroundTask() {

    }


    public void executeTask(){

        BackGroundTasks tasks = new BackGroundTasks();
        tasks.execute();
    }

    public class BackGroundTasks extends AsyncTask<String, Void, String> {


        BackGroundTasks() {
            Log.d("tstng_task", "BackGroud Task Called");


        }

        @Override
        protected void onPreExecute() {
            if (is_pBar)
            pBar.setVisibility(View.VISIBLE);

        }

        @Override
        protected String doInBackground(String... strings) {
            try {


                OkHttpClient httpClient = new OkHttpClient();

                okhttp3.Request request;

                Log.d("tstng_onPostExecute",httpClient.connectTimeoutMillis()+"");
//
              //  httpClient.setReadTimeout(15, TimeUnit.SECONDS);    // socket timeout

                if (isPost) {
                    request = new okhttp3.Request.Builder()
                            .url(urlx.trim())
                            .addHeader("Accept", "application/json")
                            .post(requestBody)
                            .build();
                } else {

                    request = new okhttp3.Request.Builder()
                            .url(urlx.trim())
                            .addHeader("Accept", "application/json")
                            .build();
                }

                okhttp3.Response response = httpClient.newCall(request).execute();

                String resss = "" + response.body().string();

                Log.d("tttttt", "" + resss);
                return "" + resss;
            } catch (IOException e) {
                e.printStackTrace();
                return "error : " + e;
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (is_pBar)
            pBar.setVisibility(View.INVISIBLE);
            Log.d("tstng_onPostExecute", "" + s);
           // if (s.contains("response"))
            delegate.processFinish(s);


        }
    }



    public interface AsyncResponse {
        void processFinish(String output);
    }





}
