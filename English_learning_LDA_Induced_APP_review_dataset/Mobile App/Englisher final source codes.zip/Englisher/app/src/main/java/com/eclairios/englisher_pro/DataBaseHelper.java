package com.eclairios.englisher_pro;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import com.eclairios.englisher_pro.model.Quiz_Score_Wrong_Ans;
import com.eclairios.englisher_pro.model.Word_details_model;
import com.opencsv.CSVReader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;


public class DataBaseHelper extends SQLiteOpenHelper {


    static final String DB_NAME = "DataBase14";

    static final String TB_NAME = "Vocabulary";
    static final String TB_NAME2 = "Conversation";
    static final String TB_NAME3 = "QuizScore";
    static final String TB_NAME4 = "WrongAns";
    static final String TB_NAME5 = "WordsDictionary";


    //Vocabulary
    static final String ID = "id";
    static final String CHAPTER_NO = "chapter_no";
    static final String ENGLISH = "english";
    static final String BANGLA = "bangla";


    //Conversation
    static final String CID = "id";
    static final String CCHAPTER_NO = "chapter_no";
    static final String CENGLISH = "english";
    static final String CBANGLA = "bangla";


    //Score
    static final String QSID = "id";
    static final String QLessonNo = "lesson_no";
    static final String Q_Millis = "millis";
    static final String Q_Score = "score";
    static final String Q_Type = "type";

    //WrongAns
    static final String WID = "id";
    static final String WLessonNo = "lesson_no";
    static final String W_Word = "word";
    static final String W_Meaning = "meaning";
    static final String W_Timestamp = "datetime";


    //Dictionary
    //no,Word,POS,Lemma,Synonyms,Antonyms,Example,definition

    static final String D_id = "did";
    static final String D_Word = "d_word";
    static final String D_Pos = "d_pos";
    static final String D_Lemma = "d_lemma";
    static final String D_Synonyms = "d_synonyms";
    static final String D_Antonyms = "d_antonyms";
    static final String D_Example = "d_example";
    static final String D_Definition = "d_definition";


    Context context;

    final static String QRY =
            " CREATE TABLE " + TB_NAME + " ( " +
                    ID + " INTEGER PRIMARY KEY AUTOINCREMENT , " +
                    CHAPTER_NO + " TEXT, " +
                    ENGLISH + " TEXT, " +
                    BANGLA + " TEXT ) ";

    final static String QRY2 =
            " CREATE TABLE " + TB_NAME2 + " ( " +
                    CID + " INTEGER PRIMARY KEY AUTOINCREMENT , " +
                    CCHAPTER_NO + " TEXT, " +
                    CENGLISH + " TEXT, " +
                    CBANGLA + " TEXT ) ";


    final static String QRY3 =
            " CREATE TABLE " + TB_NAME3 + " ( " +
                    QSID + " INTEGER PRIMARY KEY AUTOINCREMENT , " +
                    QLessonNo + " TEXT, " +
                    Q_Score + " TEXT, " +
                    Q_Millis + " TEXT, " +
                    Q_Type + " TEXT ) ";


    final static String QRY4 =
            " CREATE TABLE " + TB_NAME4 + " ( " +
                    WID + " INTEGER PRIMARY KEY AUTOINCREMENT , " +
                    WLessonNo + " TEXT, " +
                    W_Word + " TEXT, " +
                    W_Meaning + " TEXT, " +
                    W_Timestamp + " TEXT ) ";


    final static String QRY5 =
            " CREATE TABLE " + TB_NAME5 + " ( " +
                    D_id + " INTEGER PRIMARY KEY AUTOINCREMENT , " +
                    D_Word + " TEXT, " +
                    D_Pos + " TEXT, " +
                    D_Lemma + " TEXT, " +
                    D_Synonyms + " TEXT, " +
                    D_Antonyms + " TEXT, " +
                    D_Example + " TEXT, " +
                    D_Definition + " TEXT ) ";


    public DataBaseHelper(Context context) {
        super(context, DB_NAME, null, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(QRY);
        db.execSQL(QRY2);
        db.execSQL(QRY3);
        db.execSQL(QRY4);
        db.execSQL(QRY5);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public String GetAVocabulary(){
        String vocab="";

        return vocab;
    }

    public void myFunc(Context ctx) {

        InputStream inputStream;

        inputStream = ctx.getResources().openRawResource(R.raw.vocab01);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));


        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        //
        db.beginTransaction();
        try {
            String csvLine;
            int i = 0;
            while ((csvLine = reader.readLine()) != null) {
                Log.i("ddd", "" + i + "csvline" + csvLine);
                String[] row = csvLine.split(",");
               // ClassVocabulory set = new ClassVocabulory();
//                set.setCHAPTER_NO(row[0]);
//                set.setENGLISH(row[1]);
//                set.setBANGLA(row[2]);

                //  InsertData(set);

                cv.put(CHAPTER_NO, row[0]);

                cv.put(ENGLISH, row[1].replace("\"",""));
                cv.put(BANGLA, row[2].replace("\"",""));


                String tag = "Method_Json_parse";
                Log.d(tag, row[0]+ "");

                long k =
                        db.insert(TB_NAME, null, cv);

                if (k > 0) {
                    Log.d("ddd", "inxerted");
                    //Toast.makeText(context, "Data Successfully Inserted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
                }


                i++;
            }
            db.setTransactionSuccessful();
            //


        } catch (IOException ex) {
            throw new RuntimeException("Error in reading CSV file: " + ex);
        } finally {
            db.endTransaction();

        }


    }

    public void myFunc2(Context ctx) {


        InputStream inputStream;

        inputStream = ctx.getResources().openRawResource(R.raw.sentences01);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        CSVReader csvReader = new CSVReader(reader);

//
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();


        db.beginTransaction();
        try {
            String[] csvline;
            int i = 0;
           // while ((csvLine = reader.readLine()) != null) {
            while ((csvline = csvReader.readNext()) != null) {

               // Log.i("ddd", "" + i + "csvline" + csvLine);
               // String[] row = csvLine.split(",,");
               // ClassVocabulory set = new ClassVocabulory();

              //  set.setCHAPTER_NO(row[0]);

                String english = csvline[1];
                if (csvline[1].contains("\"")) {
                    english = csvline[1].substring(1, csvline[1].length() - 2);

                }


                String bangla = csvline[2];
                if (csvline[2].contains("\"")) {
                    bangla = csvline[2].substring(1, csvline[2].length() - 2);

                }


                //   InsertData2(set);
                cv.put(CCHAPTER_NO, csvline[0]);

                cv.put(CENGLISH, english);
                cv.put(CBANGLA, bangla);


                String tag = "Method_Json_parse";
                Log.d(tag, csvline[0]+ "");

                long k =
                        db.insert(TB_NAME2, null, cv);

                if (k > 0) {
                    Log.d("ddd", "inxerted");
                    //Toast.makeText(context, "Data Successfully Inserted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
                }


                i++;
            }
            db.setTransactionSuccessful();


        } catch (IOException ex) {
            throw new RuntimeException("Error in reading CSV file: " + ex);
        } finally {
            db.endTransaction();

        }
//


    }


    public void myFunc3(Context ctx) {

        InputStream inputStream;

        inputStream = ctx.getResources().openRawResource(R.raw.dict_en);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        CSVReader csvReader = new CSVReader(reader);
        SQLiteDatabase db = this.getWritableDatabase();


        db.beginTransaction();
        try {
            //   String csvLine;
            int i = 0;
            String[] csvline;
            while ((csvline = csvReader.readNext()) != null) {

                //  Log.i("ddd",""+csvline[0]+"::"+csvline[7]);


               // ClassDictionary set = new ClassDictionary();

                if (i > 0) {
//                    set.setID(csvline[0]);
//                    set.setWORD(csvline[1]);
//                    set.setPOS(csvline[2]);
//                    set.setLEMMA(csvline[3]);
//                    set.setSYNONYMS(csvline[4]);
//                    set.setANTONYMS(csvline[5]);
//                    set.setEXAMPLE(csvline[6]);
//                    set.setDEFINITION(csvline[7]);
                    //InsertData3(set);
                    ContentValues cv = new ContentValues();


                    //   cv.put(D_id, "");
                    cv.put(D_Word, csvline[1]);
                    cv.put(D_Pos, csvline[2]);
                    cv.put(D_Lemma, csvline[3]);
                    cv.put(D_Synonyms, csvline[4]);
                    cv.put(D_Antonyms, csvline[5]);
                    cv.put(D_Example, csvline[6]);
                    cv.put(D_Definition, csvline[7]);


                    String tag = "Method_Json_parse";

                    long k =
                            db.insert(TB_NAME5, null, cv);

                    if (k > 0) {
                        Log.d("dddd", "inxertedd " + csvline[0]);
                        //Toast.makeText(context, "Data Successfully Inserted", Toast.LENGTH_SHORT).show();
                    } else {
                        Log.d("ddd", "something went wrongg");

                        //  Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
                    }

                }
                i++;
            }
            db.setTransactionSuccessful();


        } catch (IOException ex) {
            throw new RuntimeException("Error in reading CSV file: " + ex);
        }finally {
            db.endTransaction();

        }


    }


    public long InsertData(ClassVocabulory obj) {

        Log.d("backupfromserver", "insert");
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();


        cv.put(CHAPTER_NO, obj.getCHAPTER_NO());

        cv.put(ENGLISH, obj.getENGLISH());
        cv.put(BANGLA, obj.getBANGLA());


        String tag = "Method_Json_parse";
        Log.d(tag, obj.getCHAPTER_NO() + "");

        long k =
                db.insert(TB_NAME, null, cv);

        if (k > 0) {
            Log.d("ddd", "inxerted");
            //Toast.makeText(context, "Data Successfully Inserted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
        }

        return k;
    }

    public long InsertData2(ClassVocabulory obj) {

        Log.d("backupfromserver", "insert");
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();


        cv.put(CCHAPTER_NO, obj.getCHAPTER_NO());

        cv.put(CENGLISH, obj.getENGLISH());
        cv.put(CBANGLA, obj.getBANGLA());


        String tag = "Method_Json_parse";
        Log.d(tag, obj.getCHAPTER_NO() + "");

        long k =
                db.insert(TB_NAME2, null, cv);

        if (k > 0) {
            Log.d("ddd", "inxerted");
            //Toast.makeText(context, "Data Successfully Inserted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
        }

        return k;
    }

    public long InsertData3(ClassDictionary obj) {

        Log.d("backupfromserver", "insert");
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();


        //   cv.put(D_id, "");
        cv.put(D_Word, obj.getWORD());
        cv.put(D_Pos, obj.getPOS());
        cv.put(D_Lemma, obj.getLEMMA());
        cv.put(D_Synonyms, obj.getSYNONYMS());
        cv.put(D_Antonyms, obj.getANTONYMS());
        cv.put(D_Example, obj.getEXAMPLE());
        cv.put(D_Definition, obj.getDEFINITION());


        String tag = "Method_Json_parse";

        long k =
                db.insert(TB_NAME5, null, cv);

        if (k > 0) {
            Log.d("dddd", "inxertedd " + obj.getID());
            //Toast.makeText(context, "Data Successfully Inserted", Toast.LENGTH_SHORT).show();
        } else {
            Log.d("ddd", "something went wrongg");

            //  Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
        }

        return k;
    }

    public long InsertData_Quiz_Score(Quiz_Score_Wrong_Ans obj) {

        Log.d("backupfromserver", "insert");
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();


        cv.put(QLessonNo, obj.getQLessonNo());

        cv.put(Q_Score, obj.getQ_Score());
        cv.put(Q_Millis, obj.getQ_Millis());
        cv.put(Q_Type, obj.getQ_Type());


        String tag = "Method_Json_parse";
        Log.d(tag, obj.getQ_Score() + "");

        long k =
                db.insert(TB_NAME3, null, cv);

        if (k > 0) {
            Log.d("ddd", "inxerted");
            //Toast.makeText(context, "Data Successfully Inserted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
        }

        return k;
    }

    public long InsertData_Wrong_Ans(Quiz_Score_Wrong_Ans obj) {

        Log.d("backupfromserver", "insert");
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();


        cv.put(WLessonNo, obj.getWLessonNo());

        cv.put(W_Word, obj.getW_Word());
        cv.put(W_Meaning, obj.getW_Meaning());
        cv.put(W_Timestamp, System.currentTimeMillis() + "");


        String tag = "cccc";
        Log.d(tag, System.currentTimeMillis() + "");

        long k =
                db.insert(TB_NAME4, null, cv);

        if (k > 0) {
            Log.d("ddd", "inxerted");
            //Toast.makeText(context, "Data Successfully Inserted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
        }

        return k;
    }


    public ArrayList<Integer> ShowAll_Listen_Read() {

        ArrayList<Integer> mm = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM " + TB_NAME3, null);
        int cx = 0;
        int read = 0;
        int listen = 0;
        while (c.moveToNext()) {
            int id = c.getInt(0);
            String lesson_no = c.getString(1);
            String score = c.getString(2);
            String millis = c.getString(3);
            String type = c.getString(4);


            Log.d("type_testing", "type : " + type);
            if (type.equals("listening")) {
                listen++;
            } else if (type.equals("reading")) {
                read++;
            }

            Log.d("type_testing", "listen : " + listen);
            Log.d("type_testing", "read : " + read);

            cx++;
        }
        mm.add(listen);
        mm.add(read);

        return mm;
    }

    public HashMap ShowAll() {

        HashMap<String, ArrayList> map = new HashMap<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM " + TB_NAME, null);
        int cx = 0;
        while (c.moveToNext()) {
            ArrayList<String> allRecord = new ArrayList();
            int id = c.getInt(0);
            String chap_name = c.getString(1);
            String chap_name_turk = c.getString(2);
            String chap_no = c.getString(3);
            String title = c.getString(4);
            String title_turk = c.getString(5);
            String img1 = c.getString(6);
            String img2 = c.getString(7);
            String eng = c.getString(8);
            String turkish = c.getString(9);
            String status = c.getString(10);


            //  String record= id+":"+name+":"+amount+":"+type+":"+cat+":"+uid+":"+date+":"+status+":"+desc+":"+repeate;

            // String idsName=id+"::"+name+"::"+amount+"::"+type+"::"+cat+"::"+
            //         catcode+"::"+uid+"::"+day+"::"+month+"::"+year+"::"+
            //         millisec+"::"+status+"::"+desc+"::"+repeate+"::"+status2;
            allRecord.add(id + "");
            allRecord.add(chap_name);
            allRecord.add(chap_name_turk);
            allRecord.add(chap_no);
            allRecord.add(title);
            allRecord.add(title_turk);
            allRecord.add(img1);
            allRecord.add(img2);
            allRecord.add(eng);
            allRecord.add(turkish);
            allRecord.add(status);

            map.put(cx + "", allRecord);
            cx++;
        }

        return map;
    }

    public HashMap ShowAllQuiz() {

        HashMap<String, ArrayList> map = new HashMap<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM " + TB_NAME3, null);
        int cx = 0;
        ArrayList<String> idArr = new ArrayList();
        ArrayList<String> lesson_noArr = new ArrayList();
        ArrayList<String> scoreArr = new ArrayList();
        ArrayList<String> dateArr = new ArrayList();
        ArrayList<String> typeArr = new ArrayList();
        while (c.moveToNext()) {
            int id = c.getInt(0);
            String lesson_no = c.getString(1);
            String score = c.getString(2);
            String millis = c.getString(3);
            String type = c.getString(4);


            Calendar clndr = Calendar.getInstance();
            clndr.setTimeInMillis(Long.parseLong(millis));
            String dateTime = clndr.get(Calendar.DAY_OF_MONTH) + "/" + clndr.get(Calendar.MONTH) + "/" + clndr.get(Calendar.YEAR);
            idArr.add(id + "");
            lesson_noArr.add(lesson_no);
            scoreArr.add(score);
            dateArr.add(dateTime);
            typeArr.add(type);


            cx++;
        }

        map.put("id_arr", idArr);
        map.put("lesson_no_arr", lesson_noArr);
        map.put("score_arr", scoreArr);
        map.put("date_arr", dateArr);
        map.put("type_arr", typeArr);
        return map;
    }
    public String GetRandVocab() {

        HashMap<String, ArrayList> map = new HashMap<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM " + TB_NAME+ " ORDER BY RANDOM() LIMIT 1;", null);
        int cx = 0;
        String vocab="";
        while (c.moveToNext()) {
             vocab = c.getString(2);




           // cx++;
       }


        return vocab;
    }


    public ArrayList<ClassVocabulory> ShowVocabOneChapter(String C_no) {

        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<ClassVocabulory> Records = new ArrayList();

        Cursor c = db.rawQuery("SELECT * FROM " + TB_NAME + " WHERE " + CHAPTER_NO + " = " + C_no, null);
        int cx = 0;
        while (c.moveToNext()) {
            int id = c.getInt(0);
            String chap_no = c.getString(1);
            String eng = c.getString(2);
            String bangla = c.getString(3);

            Records.add(new ClassVocabulory(id + "", chap_no, eng, bangla));

            cx++;
        }

        return Records;
    }

    public ArrayList<ClassVocabulory> ShowSentanceOneChapter(String C_no) {

        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<ClassVocabulory> Records = new ArrayList();

        Cursor c = db.rawQuery("SELECT * FROM " + TB_NAME2 + " WHERE " + CHAPTER_NO + " = " + C_no, null);
        int cx = 0;
        while (c.moveToNext()) {
            int id = c.getInt(0);
            String chap_no = c.getString(1);
            String eng = c.getString(2);
            String bangla = c.getString(3);

            Records.add(new ClassVocabulory(id + "", chap_no, eng, bangla));

            cx++;
        }

        return Records;
    }

    public ArrayList<Quiz_Score_Wrong_Ans> ShowWrongAns() {

        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<Quiz_Score_Wrong_Ans> Records = new ArrayList();

        Cursor c = db.rawQuery("SELECT * FROM " + TB_NAME4 + " ORDER BY datetime DESC", null);
        int cx = 0;
        while (c.moveToNext()) {
            int id = c.getInt(0);
            String chap_no = c.getString(1);
            String bangla = c.getString(2);
            String eng = c.getString(3);
            String timestamp = c.getString(4);

            Records.add(new Quiz_Score_Wrong_Ans(id + "", chap_no, bangla, eng, timestamp + ""));

            cx++;
        }

        return Records;
    }


    public ArrayList showSingle(String nn) {
        ArrayList<String> allRecord = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + TB_NAME + " WHERE " + ID + " = " + nn, null);
        String data = "";
        while (c.moveToNext()) {
            int id = c.getInt(0);
            String chap_name = c.getString(1);
            String chap_name_turk = c.getString(2);
            String chap_no = c.getString(3);
            String title = c.getString(4);
            String title_turk = c.getString(5);
            String img1 = c.getString(6);
            String img2 = c.getString(7);
            String eng = c.getString(8);
            String turkish = c.getString(9);
            String status = c.getString(10);

            allRecord.add(id + "");
            allRecord.add(chap_name);
            allRecord.add(chap_name_turk);
            allRecord.add(chap_no);
            allRecord.add(title);
            allRecord.add(title_turk);
            allRecord.add(img1);
            allRecord.add(img2);
            allRecord.add(eng);
            allRecord.add(turkish);
            allRecord.add(status);

        }
        return allRecord;
    }

    public List<Book> getchapter(int chapter_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Book> list_chapter = new ArrayList();

        Cursor c = db.rawQuery("select * from " + TB_NAME + " where " + CHAPTER_NO + " = " + chapter_id, null);
        while (c.moveToNext()) {
            int id = c.getInt(0);

            Book book = new Book();
            String chap_name = c.getString(1);
            String chap_name_turk = c.getString(2);
            String chap_no = c.getString(3);
            String title = c.getString(4);
            String title_turk = c.getString(5);
            String img1 = c.getString(6);
            String img2 = c.getString(7);
            String eng = c.getString(8);
            String turkish = c.getString(9);
            String status = c.getString(10);

            book.setChapter_id(chap_no);
            book.setChapter_name(chap_name);
            book.setChapter_name(chap_name_turk);
            book.setPage_title(title);
            book.setPage_title_turk(title_turk);
            book.setChapter_image1(img1);
            book.setChapter_image2(img2);
            book.setChapter_page_text(eng);
            book.setChapter_page_text_turk(turkish);
            list_chapter.add(book);
        }

        return list_chapter;
    }

    public ArrayList<Word_details_model> ShowWordDetails(String Word) {
        ArrayList<Word_details_model> Records = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM " + TB_NAME5 + " WHERE " + D_Word + " = '" + Word + "'", null);
        int cx = 0;
        while (c.moveToNext()) {
            int id = c.getInt(0);
            String word = c.getString(1);
            String pos = c.getString(2);
            String lemma = c.getString(3);
            String syno = c.getString(4);
            String anto = c.getString(5);
            String example = c.getString(6);
            String defi = c.getString(7);

            Records.add(new Word_details_model(word, pos, lemma, syno, anto, example, defi));

            cx++;
        }

        return Records;
    }


//
//    public ArrayList showSingleDist() {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        //
//        Cursor c = db.rawQuery("SELECT DISTINCT " + CHAPTER_NO + " FROM " + TB_NAME, null);
//        String data = "";
//        while (c.moveToNext()) {
//            String chap_name = c.getString(0);
//            Log.d("hhhhh", chap_name + "");
//
//            //  String record= id+":"+name+":"+amount+":"+type+":"+cat+":"+uid+":"+date+":"+status+":"+desc+":"+repeate;
//
//            //  String idsName=id+"::"+name+"::"+amount+"::"+type+"::"+cat+"::"+catcode+"::"+uid+"::"+date+"::"+status+"::"+desc+"::"+repeate;
//            allRecord.add(chap_name);
//            //  data+=catcode+"\n";
//        }
//
//        return allRecord;
//    }
//
//    public ArrayList showSingleDistChapName() {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        //
//        Cursor c = db.rawQuery("SELECT DISTINCT " + CHAPTER_NAME+ " FROM " + TB_NAME, null);
//        String data = "";
//        while (c.moveToNext()) {
//            String chap_name = c.getString(0);
//            Log.d("hhhhh", chap_name + "");
//
//            //  String record= id+":"+name+":"+amount+":"+type+":"+cat+":"+uid+":"+date+":"+status+":"+desc+":"+repeate;
//
//            //  String idsName=id+"::"+name+"::"+amount+"::"+type+"::"+cat+"::"+catcode+"::"+uid+"::"+date+"::"+status+"::"+desc+"::"+repeate;
//            allRecord.add(chap_name);
//            //  data+=catcode+"\n";
//        }
//
//        return allRecord;
//    }
//
//
//
//    public ArrayList showSingleDistChapName_Turk() {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        //
//        Cursor c = db.rawQuery("SELECT DISTINCT " + CHAPTER_NAME_TURK+ " FROM " + TB_NAME, null);
//        String data = "";
//        while (c.moveToNext()) {
//            String chap_name = c.getString(0);
//            Log.d("hhhhh", chap_name + "");
//
//            //  String record= id+":"+name+":"+amount+":"+type+":"+cat+":"+uid+":"+date+":"+status+":"+desc+":"+repeate;
//
//            //  String idsName=id+"::"+name+"::"+amount+"::"+type+"::"+cat+"::"+catcode+"::"+uid+"::"+date+"::"+status+"::"+desc+"::"+repeate;
//            allRecord.add(chap_name);
//            //  data+=catcode+"\n";
//        }
//
//        return allRecord;
//    }
//
//
//
//    public ArrayList showSingleChap_Notes(String ch_no) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        //
//        Cursor c = db.rawQuery("SELECT "+ENGLISH+"  FROM " + TB_NAME+" WHERE "+CHAPTER_NO+" = "+ch_no, null);
//        String data = "";
//        while (c.moveToNext()) {
//            String eng = c.getString(0);
//
//            //  String record= id+":"+name+":"+amount+":"+type+":"+cat+":"+uid+":"+date+":"+status+":"+desc+":"+repeate;
//
//            //  String idsName=id+"::"+name+"::"+amount+"::"+type+"::"+cat+"::"+catcode+"::"+uid+"::"+date+"::"+status+"::"+desc+"::"+repeate;
//            allRecord.add(eng);
//            //  data+=catcode+"\n";
//        }
//
//        return allRecord;
//    }
//
//
//
//    public ArrayList showSingleChap_Titles(String ch_no) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        //
//        Cursor c = db.rawQuery("SELECT "+TITLE+"  FROM " + TB_NAME+" WHERE "+CHAPTER_NO+" = "+ch_no, null);
//        String data = "";
//        while (c.moveToNext()) {
//            String eng = c.getString(0);
//
//            //  String record= id+":"+name+":"+amount+":"+type+":"+cat+":"+uid+":"+date+":"+status+":"+desc+":"+repeate;
//
//            //  String idsName=id+"::"+name+"::"+amount+"::"+type+"::"+cat+"::"+catcode+"::"+uid+"::"+date+"::"+status+"::"+desc+"::"+repeate;
//            allRecord.add(eng);
//            //  data+=catcode+"\n";
//        }
//
//        return allRecord;
//    }
//
//
//
//    public ArrayList showAllChap_Titles() {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        //
//        Cursor c = db.rawQuery("SELECT "+TITLE+"  FROM " + TB_NAME, null);
//        String data = "";
//        while (c.moveToNext()) {
//            String eng = c.getString(0);
//
//            //  String record= id+":"+name+":"+amount+":"+type+":"+cat+":"+uid+":"+date+":"+status+":"+desc+":"+repeate;
//
//            //  String idsName=id+"::"+name+"::"+amount+"::"+type+"::"+cat+"::"+catcode+"::"+uid+"::"+date+"::"+status+"::"+desc+"::"+repeate;
//            allRecord.add(eng);
//            //  data+=catcode+"\n";
//        }
//
//        return allRecord;
//    }
//
//
//
//
//    public ArrayList showAllChap_Titles_Turk() {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        //
//        Cursor c = db.rawQuery("SELECT "+TITLE_TURKISH+"  FROM " + TB_NAME, null);
//        String data = "";
//        while (c.moveToNext()) {
//            String eng = c.getString(0);
//
//            //  String record= id+":"+name+":"+amount+":"+type+":"+cat+":"+uid+":"+date+":"+status+":"+desc+":"+repeate;
//
//            //  String idsName=id+"::"+name+"::"+amount+"::"+type+"::"+cat+"::"+catcode+"::"+uid+"::"+date+"::"+status+"::"+desc+"::"+repeate;
//            allRecord.add(eng);
//            //  data+=catcode+"\n";
//        }
//
//        return allRecord;
//    }
//
//
//
//    public ArrayList showAllChap_Notes() {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        //
//        Cursor c = db.rawQuery("SELECT "+ENGLISH+"  FROM " + TB_NAME, null);
//        String data = "";
//        while (c.moveToNext()) {
//            String eng = c.getString(0);
//
//            //  String record= id+":"+name+":"+amount+":"+type+":"+cat+":"+uid+":"+date+":"+status+":"+desc+":"+repeate;
//
//            //  String idsName=id+"::"+name+"::"+amount+"::"+type+"::"+cat+"::"+catcode+"::"+uid+"::"+date+"::"+status+"::"+desc+"::"+repeate;
//            allRecord.add(eng);
//            //  data+=catcode+"\n";
//        }
//
//        return allRecord;
//    }
//
//
//
//    public ArrayList showAllChap_Notes_Turk() {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        //
//        Cursor c = db.rawQuery("SELECT "+TURKISH+"  FROM " + TB_NAME, null);
//        String data = "";
//        while (c.moveToNext()) {
//            String eng = c.getString(0);
//
//            //  String record= id+":"+name+":"+amount+":"+type+":"+cat+":"+uid+":"+date+":"+status+":"+desc+":"+repeate;
//
//            //  String idsName=id+"::"+name+"::"+amount+"::"+type+"::"+cat+"::"+catcode+"::"+uid+"::"+date+"::"+status+"::"+desc+"::"+repeate;
//            allRecord.add(eng);
//            //  data+=catcode+"\n";
//        }
//
//        return allRecord;
//    }
//
//
//
//    public ArrayList showSingleChap_Notes_Turk(String chap) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        //
//        Cursor c = db.rawQuery("SELECT "+TURKISH+"  FROM " + TB_NAME+" WHERE "+CHAPTER_NO+" = "+chap, null);
//        String data = "";
//        while (c.moveToNext()) {
//            String eng = c.getString(0);
//
//            //  String record= id+":"+name+":"+amount+":"+type+":"+cat+":"+uid+":"+date+":"+status+":"+desc+":"+repeate;
//
//            //  String idsName=id+"::"+name+"::"+amount+"::"+type+"::"+cat+"::"+catcode+"::"+uid+"::"+date+"::"+status+"::"+desc+"::"+repeate;
//            allRecord.add(eng);
//            //  data+=catcode+"\n";
//        }
//
//        return allRecord;
//    }
//
//
//    public ArrayList showSingleChap_Titles_Turk(String chap) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        //
//        Cursor c = db.rawQuery("SELECT "+TITLE_TURKISH+"  FROM " + TB_NAME+" WHERE "+CHAPTER_NO+" = "+chap, null);
//        String data = "";
//        while (c.moveToNext()) {
//            String eng = c.getString(0);
//
//            //  String record= id+":"+name+":"+amount+":"+type+":"+cat+":"+uid+":"+date+":"+status+":"+desc+":"+repeate;
//
//            //  String idsName=id+"::"+name+"::"+amount+"::"+type+"::"+cat+"::"+catcode+"::"+uid+"::"+date+"::"+status+"::"+desc+"::"+repeate;
//            allRecord.add(eng);
//            //  data+=catcode+"\n";
//        }
//
//        return allRecord;
//    }
//
//
//
//    public ArrayList showAllChap_No_ByTitles(String title) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        Log.d("1234qaz",""+title);
//        //
//        Cursor cursor = null;
//        try {
//            cursor = db.rawQuery("SELECT "+CHAPTER_NAME+"  FROM " + TB_NAME+" WHERE "+TITLE+" = '"+title+"'", null);
//            while (cursor.moveToNext()) {
//                String eng = cursor.getString(0);
//                allRecord.add(eng);
//            }
//            // do some work with the cursor here.
//        } finally {
//            // this gets called even if there is an exception somewhere above
//            if(cursor != null)
//                cursor.close();
//        }
//
//
//        return allRecord;
//    }
//
//
//    public ArrayList showAllChap_No_ByTitles_Turk(String title) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        Log.d("1234qaz",""+title);
//        //
//        Cursor cursor = null;
//        try {
//            cursor = db.rawQuery("SELECT "+CHAPTER_NAME_TURK+"  FROM " + TB_NAME+" WHERE "+TITLE_TURKISH+" = '"+title+"'", null);
//            while (cursor.moveToNext()) {
//                String eng = cursor.getString(0);
//                allRecord.add(eng);
//            }
//            // do some work with the cursor here.
//        } finally {
//            // this gets called even if there is an exception somewhere above
//            if(cursor != null)
//                cursor.close();
//        }
//
//
//        return allRecord;
//    }
//
//    public ArrayList showAllChap_No_ByTitles_Id(String title) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        Log.d("1234qaz",""+title);
//        //
//        Cursor cursor = null;
//        try {
//            cursor = db.rawQuery("SELECT "+CHAPTER_NO+"  FROM " + TB_NAME+" WHERE "+TITLE+" = '"+title+"'", null);
//            while (cursor.moveToNext()) {
//                String eng = cursor.getString(0);
//                allRecord.add(eng);
//            }
//            // do some work with the cursor here.
//        } finally {
//            // this gets called even if there is an exception somewhere above
//            if(cursor != null)
//                cursor.close();
//        }
//
//
//        return allRecord;
//    }
//
//
//
//    public ArrayList showAllChap_No_ByTitles_Id_Turk(String title) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        Log.d("1234qaz",""+title);
//        //
//        Cursor cursor = null;
//        try {
//            cursor = db.rawQuery("SELECT "+CHAPTER_NO+"  FROM " + TB_NAME+" WHERE "+TITLE_TURKISH+" = '"+title+"'", null);
//            while (cursor.moveToNext()) {
//                String eng = cursor.getString(0);
//                allRecord.add(eng);
//            }
//            // do some work with the cursor here.
//        } finally {
//            // this gets called even if there is an exception somewhere above
//            if(cursor != null)
//                cursor.close();
//        }
//
//
//        return allRecord;
//    }
//
//
//
//    public ArrayList showAllChap_No_ByNotes(String eng) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        Log.d("1234qaz",""+eng);
//        //
//        Cursor cursor = null;
//        try {
//           /* String query="SELECT "+CHAPTER_NAME+"  FROM " + TB_NAME;
//            cursor = db.rawQuery(query, new String[]{ eng });*/
//
//            cursor = db.rawQuery("SELECT "+CHAPTER_NAME+"  FROM " + TB_NAME+" WHERE "+ENGLISH+" = "+android.database.DatabaseUtils.sqlEscapeString(eng)+"", null);
//            while (cursor.moveToNext()) {
//                String eng1 = cursor.getString(0);
//                allRecord.add(eng1);
//            }
//            // do some work with the cursor here.
//        } finally {
//            // this gets called even if there is an exception somewhere above
//            if(cursor != null)
//                cursor.close();
//        }
//
//
//        return allRecord;
//    }
//
//
//
//    public ArrayList showAllChap_No_ByNotes_Turk(String eng) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        Log.d("1234qaz",""+eng);
//        //
//        Cursor cursor = null;
//        try {
//           /* String query="SELECT "+CHAPTER_NAME+"  FROM " + TB_NAME;
//            cursor = db.rawQuery(query, new String[]{ eng });*/
//
//            cursor = db.rawQuery("SELECT "+CHAPTER_NAME_TURK+"  FROM " + TB_NAME+" WHERE "+TURKISH+" = "+android.database.DatabaseUtils.sqlEscapeString(eng)+"", null);
//            while (cursor.moveToNext()) {
//                String eng1 = cursor.getString(0);
//                allRecord.add(eng1);
//            }
//            // do some work with the cursor here.
//        } finally {
//            // this gets called even if there is an exception somewhere above
//            if(cursor != null)
//                cursor.close();
//        }
//
//
//        return allRecord;
//    }
//
//    public ArrayList showAllChap_No_ByNotes_Id_main(String eng) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        Log.d("1234qaz",""+eng);
//        //
//        Cursor cursor = null;
//        try {
//           /* String query="SELECT "+CHAPTER_NAME+"  FROM " + TB_NAME;
//            cursor = db.rawQuery(query, new String[]{ eng });*/
//
//            cursor = db.rawQuery("SELECT "+ID+"  FROM " + TB_NAME+" WHERE "+ENGLISH+" = "+android.database.DatabaseUtils.sqlEscapeString(eng)+"", null);
//            while (cursor.moveToNext()) {
//                String eng1 = cursor.getString(0);
//                allRecord.add(eng1);
//            }
//            // do some work with the cursor here.
//        } finally {
//            // this gets called even if there is an exception somewhere above
//            if(cursor != null)
//                cursor.close();
//        }
//
//
//        return allRecord;
//    }
//
//    public ArrayList showAllChap_No_ByNotes_Id_main_Turk(String eng) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        Log.d("1234qaz",""+eng);
//        //
//        Cursor cursor = null;
//        try {
//           /* String query="SELECT "+CHAPTER_NAME+"  FROM " + TB_NAME;
//            cursor = db.rawQuery(query, new String[]{ eng });*/
//
//            cursor = db.rawQuery("SELECT "+ID+"  FROM " + TB_NAME+" WHERE "+TURKISH+" = "+android.database.DatabaseUtils.sqlEscapeString(eng)+"", null);
//            while (cursor.moveToNext()) {
//                String eng1 = cursor.getString(0);
//                allRecord.add(eng1);
//            }
//            // do some work with the cursor here.
//        } finally {
//            // this gets called even if there is an exception somewhere above
//            if(cursor != null)
//                cursor.close();
//        }
//
//
//        return allRecord;
//    }
//
//    public ArrayList showAllChap_No_ByTitles_Id_main(String eng) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        Log.d("1234qaz",""+eng);
//        //
//        Cursor cursor = null;
//        try {
//           /* String query="SELECT "+CHAPTER_NAME+"  FROM " + TB_NAME;
//            cursor = db.rawQuery(query, new String[]{ eng });*/
//
//            cursor = db.rawQuery("SELECT "+ID+"  FROM " + TB_NAME+" WHERE "+TITLE+" = "+android.database.DatabaseUtils.sqlEscapeString(eng)+"", null);
//            while (cursor.moveToNext()) {
//                String eng1 = cursor.getString(0);
//                allRecord.add(eng1);
//            }
//            // do some work with the cursor here.
//        } finally {
//            // this gets called even if there is an exception somewhere above
//            if(cursor != null)
//                cursor.close();
//        }
//
//
//        return allRecord;
//    }
//
//    public ArrayList showAllChap_No_ByTitles_Id_main_Turk(String eng) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        Log.d("1234qaz",""+eng);
//        //
//        Cursor cursor = null;
//        try {
//           /* String query="SELECT "+CHAPTER_NAME+"  FROM " + TB_NAME;
//            cursor = db.rawQuery(query, new String[]{ eng });*/
//
//            cursor = db.rawQuery("SELECT "+ID+"  FROM " + TB_NAME+" WHERE "+TITLE_TURKISH+" = "+android.database.DatabaseUtils.sqlEscapeString(eng)+"", null);
//            while (cursor.moveToNext()) {
//                String eng1 = cursor.getString(0);
//                allRecord.add(eng1);
//            }
//            // do some work with the cursor here.
//        } finally {
//            // this gets called even if there is an exception somewhere above
//            if(cursor != null)
//                cursor.close();
//        }
//
//
//        return allRecord;
//    }
//
// public ArrayList showAllChap_No_ByNotes_Id(String eng) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        Log.d("1234qaz",""+eng);
//        //
//        Cursor cursor = null;
//        try {
//           /* String query="SELECT "+CHAPTER_NAME+"  FROM " + TB_NAME;
//            cursor = db.rawQuery(query, new String[]{ eng });*/
//
//            cursor = db.rawQuery("SELECT "+CHAPTER_NO+"  FROM " + TB_NAME+" WHERE "+ENGLISH+" = "+android.database.DatabaseUtils.sqlEscapeString(eng)+"", null);
//            while (cursor.moveToNext()) {
//                String eng1 = cursor.getString(0);
//                allRecord.add(eng1);
//            }
//            // do some work with the cursor here.
//        } finally {
//            // this gets called even if there is an exception somewhere above
//            if(cursor != null)
//                cursor.close();
//        }
//
//
//        return allRecord;
//    }
//
//
// public ArrayList showAllChap_No_ByNotes_Id_Turk(String eng) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        Log.d("1234qaz",""+eng);
//        //
//        Cursor cursor = null;
//        try {
//           /* String query="SELECT "+CHAPTER_NAME+"  FROM " + TB_NAME;
//            cursor = db.rawQuery(query, new String[]{ eng });*/
//
//            cursor = db.rawQuery("SELECT "+CHAPTER_NO+"  FROM " + TB_NAME+" WHERE "+TURKISH+" = "+android.database.DatabaseUtils.sqlEscapeString(eng)+"", null);
//            while (cursor.moveToNext()) {
//                String eng1 = cursor.getString(0);
//                allRecord.add(eng1);
//            }
//            // do some work with the cursor here.
//        } finally {
//            // this gets called even if there is an exception somewhere above
//            if(cursor != null)
//                cursor.close();
//        }
//
//
//        return allRecord;
//    }
//
//
// public ArrayList showAllChap_No_ByNotes_Frst_Id(String eng) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        Log.d("1234qaz",""+eng);
//        //
//        Cursor cursor = null;
//        try {
//           /* String query="SELECT "+CHAPTER_NAME+"  FROM " + TB_NAME;
//            cursor = db.rawQuery(query, new String[]{ eng });*/
//
//            cursor = db.rawQuery("SELECT "+ID+"  FROM " + TB_NAME+" WHERE "+CHAPTER_NO+" = "+android.database.DatabaseUtils.sqlEscapeString(eng)+"", null);
//            while (cursor.moveToNext()) {
//                String eng1 = cursor.getString(0);
//                allRecord.add(eng1);
//            }
//            // do some work with the cursor here.
//        } finally {
//            // this gets called even if there is an exception somewhere above
//            if(cursor != null)
//                cursor.close();
//        }
//
//
//        return allRecord;
//    }
//
//
//
//
// public ArrayList showAllChap_No_ByTitles_Frst_Id(String eng) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        ArrayList<String> allRecord = new ArrayList();
//        Log.d("1234qaz",""+eng);
//        //
//        Cursor cursor = null;
//        try {
//           /* String query="SELECT "+CHAPTER_NAME+"  FROM " + TB_NAME;
//            cursor = db.rawQuery(query, new String[]{ eng });*/
//
//            cursor = db.rawQuery("SELECT "+ID+"  FROM " + TB_NAME+" WHERE "+CHAPTER_NO+" = "+android.database.DatabaseUtils.sqlEscapeString(eng)+"", null);
//            while (cursor.moveToNext()) {
//                String eng1 = cursor.getString(0);
//                allRecord.add(eng1);
//            }
//            // do some work with the cursor here.
//        } finally {
//            // this gets called even if there is an exception somewhere above
//            if(cursor != null)
//                cursor.close();
//        }
//
//
//        return allRecord;
//    }
//
//
//
//    public void updateData(ClassVocabulory obj, int id) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues cv = new ContentValues();
//
//
//        cv.put(ID, id);
//        cv.put(CHAPTER_NAME, obj.getCHAPTER_NAME());
//        cv.put(CHAPTER_NO, obj.getCHAPTER_NO());
//        cv.put(TITLE, obj.getTITLE());
//        cv.put(TITLE_TURKISH, obj.getTITLE_TURKISH());
//        cv.put(IMAGE_1, obj.getIMAGE_1());
//        cv.put(IMAGE_2, obj.getIMAGE_2());
//        cv.put(ENGLISH, obj.getENGLISH());
//        cv.put(TURKISH, obj.getTURKISH());
//        cv.put(STATUS, obj.getSTATUS());
//
//        long k = db.update(TB_NAME, cv, ID + "=?", new String[]{id + ""});
//        if (k > 0)
//            Toast.makeText(context, "Data Successfully \n Updated", Toast.LENGTH_SHORT).show();
//        else
//            Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
//    }
//
//    public void updateDataStatus(String id, int status2) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues cv = new ContentValues();
//
//
//        cv.put(ID, id);
//        cv.put(STATUS, status2);
//
//        long k = db.update(TB_NAME, cv, ID + "=?", new String[]{id + ""});
//        if (k > 0){}
//        // Toast.makeText(context, "Status Successfully \n Updated", Toast.LENGTH_SHORT).show();
//        else{}
//        // Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
//    }
//
//    public void deleteData(int nn) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        String query = "select * from tablename where id = " + nn;
//        long id = db.delete(TB_NAME, ID + " =? ", new String[]{nn + ""});
//
//        if (id > 0){}
//        // Toast.makeText(context, "Data Successfully \n Deleted", Toast.LENGTH_SHORT).show();
//        else{}
//        // Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
//
//
//    }
//
//    public void deleteAllData() {
//        SQLiteDatabase db = this.getWritableDatabase();
//        // String query="select * from tablename where id = "+nn;
//        long id = db.delete(TB_NAME, null, null);
//
//        if (id > 0){}
//        //  Toast.makeText(context, "Data Successfully \n Deleted", Toast.LENGTH_SHORT).show();
//        else{}
//        //  Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
//
//
//    }


}
