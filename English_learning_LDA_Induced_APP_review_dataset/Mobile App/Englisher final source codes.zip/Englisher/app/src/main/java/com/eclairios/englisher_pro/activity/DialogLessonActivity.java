package com.eclairios.englisher_pro.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.eclairios.englisher_pro.R;

import java.util.ArrayList;

public class DialogLessonActivity extends AppCompatActivity {


    RelativeLayout btn_ok,btn_cancel;
    CheckBox cb_all;
    ListView list_lesson;
    ArrayList<String> lesson_on;
    String[] lesson={"Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 7","Lesson 8","Lesson 9","Lesson 10","Lesson 11","Lesson 12","Lesson 13","Lesson 14","Lesson 15","Lesson 16","Lesson 17","Lesson 18","Lesson 19","Lesson 20","Lesson 21","Lesson 22","Lesson 23"
    ,"Lesson 24","Lesson 25","Lesson 26","Lesson 27","Lesson 28","Lesson 29","Lesson 30","Lesson 31","Lesson 32","Lesson 33","Lesson 34","Lesson 35"};
    int[] status={1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    CustomAdapter adapter;
    int[] resultStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_dialog_lesson);
        this.setFinishOnTouchOutside(false);

        btn_ok=findViewById(R.id.btn_dialog_ok);
        btn_cancel=findViewById(R.id.btn_dialog_cancel);

        cb_all=findViewById(R.id.main_dialod_cbox);

        status=getIntent().getIntArrayExtra("status");
        list_lesson = findViewById(R.id.list_lesson_dialog);
        adapter=new CustomAdapter(DialogLessonActivity.this,lesson,status);
        list_lesson.setAdapter(adapter);





        cb_all.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    for (int xc=0;xc<status.length; xc++)
                        status[xc]=1;
                }else {
                    for (int xc=0;xc<status.length; xc++)
                        status[xc]=0;
                }
                adapter=new CustomAdapter(DialogLessonActivity.this,lesson,status);
                list_lesson.setAdapter(adapter);
            }
        });
        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PreferenceManager.getDefaultSharedPreferences(DialogLessonActivity.this).edit().putBoolean("isWord_on", true).apply();
                PreferenceManager.getDefaultSharedPreferences(DialogLessonActivity.this).edit().putBoolean("isMeaning_on", true).apply();
                PreferenceManager.getDefaultSharedPreferences(DialogLessonActivity.this).edit().putInt("last_pos", -1).apply();
                Intent returnIntent = new Intent(DialogLessonActivity.this,ParcticeActivity.class);
                returnIntent.putExtra("from_list","ok");

                lesson_on=new ArrayList<>();

                for (int x=0; x<resultStatus.length; x++){
                    if (resultStatus[x]==1){
                        int lsn_no=x+1;
                        lesson_on.add(lsn_no+"");
                    }
                }

                returnIntent.putStringArrayListExtra("chapter_no_arr",lesson_on);
                returnIntent.putExtra("chapter_status_arr",resultStatus);
               // Set<String>
               // PreferenceManager.getDefaultSharedPreferences(DialogLessonActivity.this).edit().putStringSet("arrayLessons", lesson_on).apply();

                if (lesson_on.size()<1)
                    Toast.makeText(DialogLessonActivity.this, "Please Select Lesson", Toast.LENGTH_SHORT).show();
                else {
                    startActivity(returnIntent);
                    // setResult(Activity.RESULT_OK,returnIntent);
                    finish();
                }
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent();
                setResult(Activity.RESULT_CANCELED, returnIntent);
                finish();
            }
        });


    }

    @Override
    public void onBackPressed() {
        Intent returnIntent = new Intent();
        setResult(Activity.RESULT_CANCELED, returnIntent);
        finish();
    }


    public class CustomAdapter extends BaseAdapter {

        String[] resultNames;



        Context context;

        private LayoutInflater inflater = null;

        public CustomAdapter(Context context, String[] names, int[] status) {
            resultNames = names;
            resultStatus = status;


            context = context;

            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        }

        @Override
        public int getCount() {
            return resultNames.length;
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        public class ViewHolder {
            TextView tvName;
            CheckBox cbStatus;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            ViewHolder vh = new ViewHolder();
            View rowView;

            rowView = inflater.inflate(R.layout.adapter_list_lesson, null);

            vh.tvName = rowView.findViewById(R.id.adptr_lesson);
            vh.cbStatus = rowView.findViewById(R.id.adptr_check_box);


            vh.tvName.setText(resultNames[position]);
            if (resultStatus[position]==1){
                vh.cbStatus.setChecked(true);
            }
            vh.cbStatus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {

                        resultStatus[position]=1;
                    } else {
resultStatus[position]=0;
                    }
                }
            });
            return rowView;

        }
    }
}
