package com.eclairios.englisher_pro.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import com.eclairios.englisher_pro.DataBaseHelper;
import com.eclairios.englisher_pro.R;
import com.eclairios.englisher_pro.adapter.CustomDialogClass;
import com.eclairios.englisher_pro.model.Quiz_Score_Wrong_Ans;
import com.eclairios.englisher_pro.service.Timer_Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Random;

public class ListenActivity extends AppCompatActivity  implements TextToSpeech.OnInitListener {


    //TextView tx_meaning;
    TextView tx_ans_1, tx_ans_2, tx_ans_3, tx_ans_4;
    TextView tx_numbers,tv_timer;
    String  tx_wrong= "0", tx_right= "0", tx_score = "0";
    RadioButton rb_1, rb_2, rb_3, rb_4;
   // ImageView btn_back;
    LinearLayout lay_1, lay_2, lay_3, lay_4;
    int count=0;
    boolean isStart=false;
    String[] data, data_ans, words_lst;
    int[] data_index;
    int quiz_round = 0;
    int quiz_correct_no = 0;
    ArrayList CorrectedWords=new ArrayList();
    ArrayList MistakenWords=new ArrayList();

    DataBaseHelper dataBaseHelper;
    ImageView lay_rel;
    LinearLayout lay_ans;


    HashMap<String, String> map;
    SharedPreferences mpref;
    SharedPreferences.Editor mEditor;
    Handler handler = new Handler();
    Handler handler2 ;
    Runnable runnable = new Runnable() {
        public void run() {
            afficher();
        }
    };

    DataBaseHelper helper;

    TextToSpeech tts;
    String textforspeech;

    private void afficher() {

        isStart=true;
        count++;

        if (count==10) {
            WrongAnswer();

            isStart=false;


        }
        if (quiz_round<=9){
            handler.postDelayed(runnable, 1000);
            tv_timer.setText("Timer : 0"+(10-count)+"");

        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listen);
dataBaseHelper=new DataBaseHelper(this);

       // ConvertTextToSpeech(words_lst[currentPos]);
        /** ###################################################### */

        Intent intent = getIntent();
        data = intent.getStringArrayExtra("data_arr");
        data_ans = intent.getStringArrayExtra("data_ans_arr");
        words_lst = intent.getStringArrayExtra("all_ans_arr");
        data_index = intent.getIntArrayExtra("data_index_arr");

        /** ###################################################### */
       // tx_meaning = findViewById(R.id.listen_meaning_tx);
        tx_ans_1 = findViewById(R.id.listen_tx_ans_1);
        tx_ans_2 = findViewById(R.id.listen_tx_ans_2);
        tx_ans_3 = findViewById(R.id.listen_tx_ans_3);
        tx_ans_4 = findViewById(R.id.listen_tx_ans_4);
        tx_numbers = findViewById(R.id.tx_lesson_no_in_total);
        //tx_wrong = findViewById(R.id.listen_tx_wrong);
        //tx_right = findViewById(R.id.listen_tx_right);
        //tx_score = findViewById(R.id.listen_tx_score);
        rb_1 = findViewById(R.id.listen_rb_1);
        rb_2 = findViewById(R.id.listen_rb_2);
        rb_3 = findViewById(R.id.listen_rb_3);
        rb_4 = findViewById(R.id.listen_rb_4);
       // btn_back = findViewById(R.id.listen_back);
        lay_1 = findViewById(R.id.listen_lay_1);
        lay_2 = findViewById(R.id.listen_lay_2);
        lay_3 = findViewById(R.id.listen_lay_3);
        lay_4 = findViewById(R.id.listen_lay_4);
        lay_rel = findViewById(R.id.speaker_icon_listen);
        lay_ans = findViewById(R.id.linear_lay);

        tv_timer = (TextView) findViewById(R.id.tv_timer);
        helper=new DataBaseHelper(this);
        map = new HashMap<String, String>();
        tts=new TextToSpeech(this,this);
        /*tts=new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {

                if(status == TextToSpeech.SUCCESS){

                    tts.setSpeechRate(0.8f);
                    int result=tts.setLanguage(new Locale("bn"));
                    if(result==TextToSpeech.LANG_MISSING_DATA ||
                            result==TextToSpeech.LANG_NOT_SUPPORTED){
                        Log.e("error", "This Language is not supported");
                    }
                    else{
                        ConvertTextToSpeech(textforspeech);
                    }
                }
                else
                    Log.e("error", "Initilization Failed!");
            }
        });
*/
        /** ###################################################### */


        mpref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        mEditor = mpref.edit();
        MethodSetData();
        lay_ans.setVisibility(View.INVISIBLE);



        /** ###################################################### */
        lay_rel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lay_rel.setImageDrawable(getResources().getDrawable(R.drawable.ic_play_arrow_black_24dp));

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        lay_rel.setImageDrawable(getResources().getDrawable(R.drawable.speaker));


                    }
                }, 1000);



                if (count==0 && !isStart){

                    isStart=true;
                    textforspeech=data[quiz_round];

                    /** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
                    lay_1.setEnabled(true);
                    lay_2.setEnabled(true);
                    lay_3.setEnabled(true);
                    lay_4.setEnabled(true);
                    lay_ans.setVisibility(View.VISIBLE);
                    handler.postDelayed(runnable, 1000);
                    /** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */

                }
                ConvertTextToSpeech(data[quiz_round]);

            }
        });

        /** ###################################################### */

        rb_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lay_1.performClick();
            }
        });
        rb_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lay_2.performClick();
            }
        });
        rb_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lay_3.performClick();
            }
        });
        rb_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lay_4.performClick();
            }
        });
        lay_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rb_1.setChecked(true);
                if (quiz_correct_no == 0) {

                    tx_ans_1.setTextColor(getResources().getColor(R.color.clr_green));
                    RightAnswer();
                } else {
                    tx_ans_1.setTextColor(getResources().getColor(R.color.clr_red));
                    WrongAnswer();
                }
            }
        });

        lay_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rb_2.setChecked(true);
                if (quiz_correct_no == 1) {

                    tx_ans_2.setTextColor(getResources().getColor(R.color.clr_green));
                    RightAnswer();
                } else {
                    tx_ans_2.setTextColor(getResources().getColor(R.color.clr_red));
                    WrongAnswer();
                }
            }
        });
        lay_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rb_3.setChecked(true);
                if (quiz_correct_no == 2) {
                    tx_ans_3.setTextColor(getResources().getColor(R.color.clr_green));
                    RightAnswer();
                } else {
                    tx_ans_3.setTextColor(getResources().getColor(R.color.clr_red));
                    WrongAnswer();
                }
            }
        });
        lay_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rb_4.setChecked(true);
                if (quiz_correct_no == 3) {
                    tx_ans_4.setTextColor(getResources().getColor(R.color.clr_green));
                    RightAnswer();
                } else {
                    tx_ans_4.setTextColor(getResources().getColor(R.color.clr_red));
                    WrongAnswer();
                }
            }
        });
        /** ###################################################### */

   /*     btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });*/
    }


    private void RightAnswer() {
        lay_1.setEnabled(false);
        lay_2.setEnabled(false);
        lay_3.setEnabled(false);
        lay_4.setEnabled(false);
        int right_ans = Integer.parseInt(tx_right);
        right_ans++;
        tx_right=right_ans + "";
        Log.d("ttt:right",data_ans[quiz_round]);
        CorrectedWords.add(data_ans[quiz_round]);


        int ttl_ans=quiz_round+1;
        //tx_score.setText(tx_right.getText().toString()+"/"+ttl_ans);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (quiz_round < 9) {

                    quiz_round++;

                    MethodSetData();
                } else {

                    Quiz_Score_Wrong_Ans obj=new Quiz_Score_Wrong_Ans();
                    obj.setQ_Millis(System.currentTimeMillis()+"");

                    String chapterx = PreferenceManager.getDefaultSharedPreferences(ListenActivity.this).getString("chapter", "null");
                    obj.setQLessonNo(chapterx);
                    obj.setQ_Score(tx_right);
                    obj.setQ_Type("listening");


                    Log.d("tstng_quiz","chapter : "+chapterx);
                    Log.d("tstng_quiz","right : "+tx_right);

                    lay_rel.setEnabled(false);

                    helper.InsertData_Quiz_Score(obj);
                    handler.removeCallbacks(runnable);
                    lay_1.setEnabled(false);
                    lay_2.setEnabled(false);
                    lay_3.setEnabled(false);
                    lay_4.setEnabled(false);
                    //finish();


                    CustomDialogClass cdd=new CustomDialogClass(ListenActivity.this,tx_right,CorrectedWords,MistakenWords);
                    cdd.show();
                }
            }
        }, 1000);

    }

    private void WrongAnswer() {
        lay_1.setEnabled(false);
        lay_2.setEnabled(false);
        lay_3.setEnabled(false);
        lay_4.setEnabled(false);
        int wrong_ans = Integer.parseInt(tx_wrong);
        wrong_ans++;
        Log.d("ttt:wrong",data_ans[quiz_round]);
        MistakenWords.add(data_ans[quiz_round]);

        tx_wrong=wrong_ans + "";
        int ttl_ans=quiz_round+1;
      //  tx_score.setText(tx_right.getText().toString()+"/"+ttl_ans);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                Quiz_Score_Wrong_Ans obj=new Quiz_Score_Wrong_Ans();
                String chapterx = PreferenceManager.getDefaultSharedPreferences(ListenActivity .this).getString("chapter", "null");

                obj.setWLessonNo(chapterx);
                obj.setW_Word(data[quiz_round]);
                obj.setW_Meaning(data_ans[quiz_round]);

                helper.InsertData_Wrong_Ans(obj);
                if (quiz_round < 9) {

                    quiz_round++;
                    MethodSetData();
                } else {

                    obj.setQ_Millis(System.currentTimeMillis()+"");

                    obj.setQLessonNo(chapterx);
                    obj.setQ_Score(tx_right);
                    obj.setQ_Type("listening");


                    Log.d("tstng_quiz","chapter : "+chapterx);
                    Log.d("tstng_quiz","right : "+tx_right);

                    lay_rel.setEnabled(false);

                    helper.InsertData_Quiz_Score(obj);
                    handler.removeCallbacks(runnable);
                    lay_1.setEnabled(false);
                    lay_2.setEnabled(false);
                    lay_3.setEnabled(false);
                    lay_4.setEnabled(false);
                    // finish();


                    CustomDialogClass cdd=new CustomDialogClass(ListenActivity.this,tx_right,CorrectedWords,MistakenWords);
                    cdd.show();
                }
            }
        }, 1000);

    }

    private void MethodSetData() {

        isStart=false;
        count=0;


        lay_ans.setVisibility(View.INVISIBLE);
        /** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
        rb_1.setChecked(false);
        rb_2.setChecked(false);
        rb_3.setChecked(false);
        rb_4.setChecked(false);
        /** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
        lay_1.setEnabled(false);
        lay_2.setEnabled(false);
        lay_3.setEnabled(false);
        lay_4.setEnabled(false);
        /** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
        tx_ans_1.setTextColor(getResources().getColor(R.color.clr_black));
        tx_ans_2.setTextColor(getResources().getColor(R.color.clr_black));
        tx_ans_3.setTextColor(getResources().getColor(R.color.clr_black));
        tx_ans_4.setTextColor(getResources().getColor(R.color.clr_black));
        /** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */

        /** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
        int num = quiz_round + 1;
        tx_numbers.setText(num + "/"+data.length);
        //tx_meaning.setText(data[quiz_round]);

        String[] answers = new String[4];
        final int min = 1;
        final int max = words_lst.length - 1;
        quiz_correct_no = new Random().nextInt((3 - 1) + 1) + 1;

        Log.d("tstng_method", "max : " + max);
        for (int i = 0; i < 4; i++) {
            Log.d("tstng_method", "for loop : " + i);

            boolean is_exists = true;

            if (i == quiz_correct_no) {
                answers[i] = data_ans[quiz_round];
                Log.d("tstng_method", "correct ans round : " + quiz_round);
                Log.d("tstng_method", "correct ans : " + data_ans[0]);
                Log.d("tstng_method", "correct ans : " + answers[i]);

            } else {
                answers[i]=dataBaseHelper.GetRandVocab();
                Log.d("tstng_method", "for loop : " + is_exists);
//                while (is_exists) {
//                    Log.d("tstng_method", "while in for loop : " + is_exists);
//                    final int random = new Random().nextInt((max - min) + 1) + min;
//
//                    if (!Arrays.asList(data_index).contains(random)) {
//
//                        if (!Arrays.asList(answers).contains(words_lst[random])) {
//
//
//                            answers[i] = words_lst[random];
//                            Log.d("tstng_method", "word  in list : " + answers[i]);
//                            is_exists = false;
//                        } else
//                            Log.d("tstng_method", "word exist in list : " + words_lst[random]);
//
//                    } else
//                        Log.d("tstng_method", "word exist in list : " + words_lst[random]);
//
//                }
            }


        }

        Log.d("tstng_method", "answers : " + answers.length);
        Log.d("tstng_method", "answers no: " + quiz_correct_no);

        tx_ans_1.setText(answers[0]);
        tx_ans_2.setText(answers[1]);
        tx_ans_3.setText(answers[2]);
        tx_ans_4.setText(answers[3]);

handler.removeCallbacks(runnable);
tv_timer.setText("Timer : 00");


//now show next question after half seconds
        handler2 = new Handler();



            Runnable r = new Runnable() {
                public void run() {
                    lay_rel.performClick();


                }
            };
            handler2.postDelayed(r, 500);


    }


    @Override
    public void onInit(int i) {

        if(i == TextToSpeech.SUCCESS){

            Log.d("woww","init is called");

            //int result=tts.setLanguage(Locale.US);
            //  tts.setPitch(0.1f);
            tts.setSpeechRate(0.8f);
              int result=tts.setLanguage(new Locale("bn"));
            if(result==TextToSpeech.LANG_MISSING_DATA ||
                    result==TextToSpeech.LANG_NOT_SUPPORTED){
                Log.e("error", "This Language is not supported");
            }
            else{
                ConvertTextToSpeech(textforspeech);
            }
        }
        else
            Log.e("error", "Initilization Failed!");
    }



    private void ConvertTextToSpeech(String result) {

        // TODO Auto-generated method stub
        String text =result;
        //  tts.setOnUtteranceProgressListener(new TtsUtteranceListener());

        if(text==null||"".equals(text))
        {
//            text = "Content not available";
//            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
            map.clear();
        map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, new Random().nextInt(1000)+"");

        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onDone(String utteranceId) {
                Log.d("woww","ondone");


            }

            @Override
            public void onError(String utteranceId) {
                Log.d("woww","onError");
            }

            @Override
            public void onStart(String utteranceId) {
                Log.d("woww","onStart");
            }
        });


        tts.speak(text, TextToSpeech.QUEUE_FLUSH, map);

        //
    }


    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String str_time = intent.getStringExtra("time");
            tv_timer.setText("Timer : "+str_time);

        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(broadcastReceiver,new IntentFilter(Timer_Service.str_receiver));

    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(broadcastReceiver);
    }
}
