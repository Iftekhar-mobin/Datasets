package com.eclairios.englisher_pro.activity;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.eclairios.englisher_pro.R;
import com.eclairios.englisher_pro.adapter.LessonsAdapter;
import com.eclairios.englisher_pro.model.LessonsItem;

import java.util.ArrayList;


public class LessonsActivity extends AppCompatActivity implements LessonsAdapter.ItemListener{

    private RecyclerView recyclerView;
    private ArrayList<LessonsItem> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lessons);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        arrayList = new ArrayList<>();

        arrayList.add(new LessonsItem("Sentences 07\nVocabulary 15", "1", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 32\nVocabulary 24", "2", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 15\nVocabulary 21", "3", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 27\nVocabulary 31", "4", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 16\nVocabulary 29", "5", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 08\nVocabulary 21", "6", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 0\nVocabulary 15", "7", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 31\nVocabulary 20", "8", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 09\nVocabulary 17", "9", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 17\nVocabulary 16", "10", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 0\nVocabulary 17", "11", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 14\nVocabulary 17", "12", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 23\nVocabulary 20", "13", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 26\nVocabulary 17", "14", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 14\nVocabulary 15", "15", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 38\nVocabulary 21", "16", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 0\nVocabulary 15", "17", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 0\nVocabulary 17", "18", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 02\nVocabulary 18", "19", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 0\nVocabulary 12", "20", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 23\nVocabulary 17", "21", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 16\nVocabulary 15", "22", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 35\nVocabulary 17", "23", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 13\nVocabulary 13", "24", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 28\nVocabulary 14", "25", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 09\nVocabulary 13", "26", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 12\nVocabulary 14", "27", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 30\nVocabulary 14", "28", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 0\nVocabulary 08", "29", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 0\nVocabulary 06", "30", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 05\nVocabulary 06", "31", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 08\nVocabulary 09", "32", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 06\nVocabulary 09", "33", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 10\nVocabulary 11", "34", "#09A9FF"));
        arrayList.add(new LessonsItem("Sentences 27\nVocabulary 14", "35", "#09A9FF"));


        LessonsAdapter adapter = new LessonsAdapter(this, arrayList, this);
        recyclerView.setAdapter(adapter);


        /**
         AutoFitGridLayoutManager that auto fits the cells by the column width defined.
         **/


        /**
         Simple GridLayoutManager that spans two columns
         **/
        GridLayoutManager manager = new GridLayoutManager(this, 2, GridLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(manager);
    }

    @Override
    public void onItemClick(LessonsItem item) {

        Intent intent=new Intent(this,MenuActivity.class);
        PreferenceManager.getDefaultSharedPreferences(this).edit().putString("chapter", item.header).apply();
        startActivity(intent);
    }

}
