package com.eclairios.englisher_pro;



public class ClassVocabulory {

    String ID;
    String CHAPTER_NO;

    String ENGLISH;
    String BANGLA;

    ClassVocabulory(String id, String chapter,String english,String bangla){
        ID=id;
        CHAPTER_NO=chapter;
        ENGLISH=english;
        BANGLA=bangla;

    }
    ClassVocabulory(){}

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }


    public String getCHAPTER_NO() {
        return CHAPTER_NO;
    }

    public void setCHAPTER_NO(String CHAPTER_NO) {
        this.CHAPTER_NO = CHAPTER_NO;
    }


    public String getENGLISH() {
        return ENGLISH;
    }

    public String getBANGLA() {
        return BANGLA;
    }

    public void setBANGLA(String BANGLA) {
        this.BANGLA = BANGLA;
    }
    public void setENGLISH(String ENGLISH) {
        this.ENGLISH = ENGLISH;
    }





}
