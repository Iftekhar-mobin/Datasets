package com.eclairios.englisher_pro.activity;

import android.app.Activity;
import android.content.Context;
import android.preference.PreferenceManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.eclairios.englisher_pro.DataBaseHelper;
import com.eclairios.englisher_pro.R;
import com.eclairios.englisher_pro.TopExceptionHandler;
import com.eclairios.englisher_pro.model.Quiz_Score_Wrong_Ans;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Random;

public class WrongAnsActivity extends AppCompatActivity  implements TextToSpeech.OnInitListener{



    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    TextToSpeech tts;
    TextToSpeech tts2;
    String textforspeech;
    String textforspeech2;
    HashMap<String, String> map;
    HashMap<String, String> map2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Thread.setDefaultUncaughtExceptionHandler(new TopExceptionHandler(this));
        setContentView(R.layout.activity_wrong_ans);


        String title = PreferenceManager.getDefaultSharedPreferences(this).getString("chapter", "null");
      //  setTitle("Weakness");

        map = new HashMap<String, String>();
        map2 = new HashMap<String, String>();

        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);

        tts=new TextToSpeech(this,this);
        tts2=new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {

                if(status == TextToSpeech.SUCCESS){

                    tts2.setSpeechRate(0.8f);
                    int result=tts2.setLanguage(new Locale("bn"));
                    if(result==TextToSpeech.LANG_MISSING_DATA ||
                            result==TextToSpeech.LANG_NOT_SUPPORTED){
                        Log.e("error", "This Language is not supported");
                    }
                    else{
                        ConvertTextToSpeech2(textforspeech2);
                    }
                }
                else
                    Log.e("error", "Initilization Failed!");
            }
        });


        /**
         AdView mAdView = findViewById(R.id.adView);
         AdRequest adRequest = new AdRequest.Builder().build();
         mAdView.loadAd(adRequest);
         MobileAds.initialize(this, getResources().getString(R.string.google_app_id));
         mInterstitialAd = new InterstitialAd(this);
         mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial_ad_unit_id));
         mInterstitialAd.loadAd(new AdRequest.Builder().build());
         */


        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);


//         use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);



/**     BackGroundTask task = new BackGroundTask(this, "https://soccer.sportmonks.com/api/v2.0/Books?include=leagues,sort=name&api_token=" + Constants.APIKEY, pBar);
 task.delegate = com.eclairios.englisher.activity..this;
 task.executeTask(); */

        ArrayList<Quiz_Score_Wrong_Ans> Records = new ArrayList();
        DataBaseHelper dataBaseHelper=new DataBaseHelper(this);
        Records=dataBaseHelper.ShowWrongAns();
        String[] testArr=new String[Records.size()];
        ArrayList<String> WordsArr=new ArrayList<>();
        ArrayList<String> MeaningsArr=new ArrayList<>();
        ArrayList<String> TimestampArr=new ArrayList<>();
        ArrayList<Integer> TimesArr=new ArrayList<>();

        for (int i=0;i<Records.size();i++){


            if (!Arrays.asList(testArr).contains(Records.get(i).getW_Meaning())){
                testArr[i]=Records.get(i).getW_Meaning();
                WordsArr.add(Records.get(i).getW_Word());
                MeaningsArr.add(Records.get(i).getW_Meaning());
                TimestampArr.add(Records.get(i).getW_Timestamp());
                TimesArr.add(1);
            }else {
                testArr[i]="null";

                Log.d("tsssstng","word : "+testArr);
                Log.d("tsssstng","key : "+Records.get(i).getW_Meaning());
                int x=getElementThatContains(testArr,Records.get(i).getW_Meaning(),MeaningsArr.size());

                if (x!=-1){
                    int add_times=TimesArr.get(x);
                    add_times++;
                    TimesArr.set(x,add_times);
                }

            }

        }
        /*ArrayList<Integer> DescTimeArr=new ArrayList<>();
        String[] DescTimeArrList=new String[TimesArr.size()];
        ArrayList<Integer> DescTimeArr_demo=new ArrayList<>();

        DescTimeArr_demo=TimesArr;
        Collections.sort(DescTimeArr_demo, Collections.reverseOrder());
        for (int descList=0; descList<DescTimeArr_demo.size(); descList++){
            if(!Arrays.asList(DescTimeArrList).equals(DescTimeArr_demo.get(descList)+"")){
              DescTimeArrList[descList]=DescTimeArr_demo.get(descList)+"";
                DescTimeArr.add(DescTimeArr_demo.get(descList));
                Log.d("descList","data : "+descList+" : "+DescTimeArr_demo.get(descList));

            }else {

                DescTimeArrList[descList]="null";
            }
        }*/
        //Collections.max(DescTimeArr,Collections.)
        //rowItems.add(new RowItem("Oh, what fun!", "আহা, কী মজা!"));

        mAdapter = new WrongAnsActivity.MyAdapter(this, WordsArr,MeaningsArr,TimestampArr,TimesArr, WrongAnsActivity.this);
        recyclerView.setAdapter(mAdapter);

    }

    @Override
    public void onInit(int i) {

        if(i == TextToSpeech.SUCCESS){

            Log.d("woww","init is called");

            int result=tts.setLanguage(Locale.US);
            //  tts.setPitch(0.1f);
            tts.setSpeechRate(0.8f);
            //  int result=tts.setLanguage(new Locale("bn"));
            if(result==TextToSpeech.LANG_MISSING_DATA ||
                    result==TextToSpeech.LANG_NOT_SUPPORTED){
                Log.e("error", "This Language is not supported");
            }
            else{
                ConvertTextToSpeech(textforspeech);
            }
        }
        else
            Log.e("error", "Initilization Failed!");
    }


    public class MyAdapter extends RecyclerView.Adapter<WrongAnsActivity.MyAdapter.MyViewHolder> {
        private ArrayList<String> words;
        private ArrayList<String> meanings;
        private ArrayList<String> timestamp;
        private ArrayList<Integer> times;
        Context ctx;
        Activity activity;


        // Provide a reference to the views for each data item
        // Complex data items may need more than one view per item, and
        // you provide access to all the views for a data item in a view holder
        public class MyViewHolder extends RecyclerView.ViewHolder {
            // each data item is just a string in this case
            TextView tvword;
            TextView tvmeaning;
            TextView tvtimestamp;
            TextView tvtimes;
            RelativeLayout rel_lay;

            public MyViewHolder(View itemView) {
                super(itemView);

                rel_lay = itemView.findViewById(R.id.conver_lay);
                tvword = itemView.findViewById(R.id.ss_name);
                tvmeaning = itemView.findViewById(R.id.ss_meaning);
                tvtimestamp = itemView.findViewById(R.id.tvtimestamp);
                tvtimes = itemView.findViewById(R.id.ss_times);


            }
        }

        // Provide a suitable constructor (depends on the kind of dataset)
        public MyAdapter(Context context, ArrayList<String> word, ArrayList<String> meaning,ArrayList<String> timestamp, ArrayList<Integer> times, Activity activity1) {
            this.words=word;
            this.meanings=meaning;
            this.timestamp=timestamp;
            this.times=times;
            ctx = context;
            activity = activity1;

        }

        // Create new views (invoked by the layout manager)
        @Override
        public WrongAnsActivity.MyAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView;
            itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.row_item_wrong_ans, parent, false);

            return new WrongAnsActivity.MyAdapter.MyViewHolder(itemView);

        }


        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(WrongAnsActivity.MyAdapter.MyViewHolder holder, final int position) {
            holder.tvword.setText(words.get(position));
            holder.tvmeaning.setText(meanings.get(position));
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(Long.parseLong(timestamp.get(position)));

            int mYear = calendar.get(Calendar.YEAR);
            int mMonth = calendar.get(Calendar.MONTH);
            int mDay = calendar.get(Calendar.DAY_OF_MONTH);
            int mHrs = calendar.get(Calendar.HOUR_OF_DAY);
            int mMins = calendar.get(Calendar.MINUTE);
            int mSecs = calendar.get(Calendar.SECOND);
            String Hours=mHrs+"";
            String Minutes=mMins+"";
            String Seconds=mSecs+"";
            if(mHrs<10){
                Hours="0"+mHrs;
            }
            if(mMins<10){
                Minutes="0"+mMins;

            }
            if(mSecs<10){
                Seconds="0"+mSecs;
            }


            holder.tvtimestamp.setText(Hours+":"+Minutes+":"+Seconds+"   "+mDay+"/"+(mMonth+1));
            holder.tvtimes.setText(times.get(position)+" times");

            holder.rel_lay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   // textforspeech= rowItems.get(position).rword;
                    //textforspeech2= rowItems.get(position).rmeaning;
                    //ConvertTextToSpeech(rowItems.get(position).rword);

                }
            });




        }

        // Return the size of your dataset (invoked by the layout manager)
        @Override
        public int getItemCount() {
            return words.size();
        }


    }

    public int getElementThatContains(String[] ips, String key,int s) {
        for (int i = 0; i < s; i++) {
            if (ips[i].equals(key)) {
                return i;
            }
        }
        return -1;
    }
    private void ConvertTextToSpeech(String result) {

        // TODO Auto-generated method stub
        String text =result;
        //  tts.setOnUtteranceProgressListener(new TtsUtteranceListener());

        if(text==null||"".equals(text))
        {
//            text = "Content not available";
//            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
            map.clear();
        map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, new Random().nextInt(1000)+"");

        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onDone(String utteranceId) {
                Log.d("woww","ondone");
                ConvertTextToSpeech2(textforspeech2);
//                if(textforspeech2==null || textforspeech2.equals("")){
//                    Log.d("woww","texttospeech2 is null");
//
//                }else{
//                    Log.d("woww","texttospeech2 is NOT null");
//
//                    tts2.speak(textforspeech2, TextToSpeech.QUEUE_FLUSH, null);
//                    }

            }

            @Override
            public void onError(String utteranceId) {
                Log.d("woww","onError");
            }

            @Override
            public void onStart(String utteranceId) {
                Log.d("woww","onStart");
            }
        });


        tts.speak(text, TextToSpeech.QUEUE_FLUSH, map);

        //
    }
    private void ConvertTextToSpeech2(String result) {

        // TODO Auto-generated method stub
        String text =result;
        //  tts.setOnUtteranceProgressListener(new TtsUtteranceListener());

        if(text==null||"".equals(text))
        {
//            text = "Content not available";
//            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
//            map2.clear();
//            map2.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, new Random().nextInt(1000)+"");




            tts2.speak(text, TextToSpeech.QUEUE_FLUSH, null);

        //
    }


}
