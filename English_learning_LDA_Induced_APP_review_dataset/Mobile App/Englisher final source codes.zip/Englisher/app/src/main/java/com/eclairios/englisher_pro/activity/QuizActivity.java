package com.eclairios.englisher_pro.activity;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.eclairios.englisher_pro.DataBaseHelper;
import com.eclairios.englisher_pro.R;
import com.eclairios.englisher_pro.adapter.CustomDialogClass;
import com.eclairios.englisher_pro.model.Quiz_Score_Wrong_Ans;
import com.eclairios.englisher_pro.service.Timer_Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

public class QuizActivity extends AppCompatActivity {

    TextView tx_meaning, tx_ans_1, tx_ans_2, tx_ans_3, tx_ans_4;
    TextView tx_numbers, tx_wrong, tx_right, tx_score,tv_timer;
    ImageView rb_1, rb_2, rb_3, rb_4;
    ImageView btn_back;
    LinearLayout lay_1, lay_2, lay_3, lay_4;
    int count=0;
    String[] data, data_ans, words_lst;
    int[] data_index;
    int quiz_round = 0;
    DataBaseHelper dataBaseHelper;
    int quiz_correct_no = 0;
    ArrayList <Integer> indexes=new ArrayList();
    ArrayList CorrectedWords=new ArrayList();
    ArrayList MistakenWords=new ArrayList();
    Calendar calendar;
    SimpleDateFormat simpleDateFormat;
    String date_time;

    SharedPreferences mpref;
    SharedPreferences.Editor mEditor;
    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        public void run() {
            afficher();
        }
    };

    DataBaseHelper helper;

    private void afficher() {

        count++;

        if (count==10) {
            WrongAnswer();


        }if (quiz_round<=9){
            handler.postDelayed(runnable, 1000);
            tv_timer.setText("Timer : 0"+(10-count)+"");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        dataBaseHelper=new DataBaseHelper(this);


        /** ###################################################### */

        Intent intent = getIntent();
        data = intent.getStringArrayExtra("data_arr");
        data_ans = intent.getStringArrayExtra("data_ans_arr");
        words_lst = intent.getStringArrayExtra("all_ans_arr");
        data_index = intent.getIntArrayExtra("data_index_arr");
        Log.d("tssstnng", data[9]);
        Log.d("tssstnng", "data size " + data.length);
        Log.d("tssstnng", data_ans[0]);
        Log.d("tssstnng", "data ans size " + data_ans.length);
        Log.d("tssstnng", data_index[9] + "");
        Log.d("tssstnng", "data size " + data_index.length);
        Log.d("tssstnng", words_lst.length + " words array lenght");
        /** ###################################################### */
        tx_meaning = findViewById(R.id.quiz_meaning_tx);
        tx_ans_1 = findViewById(R.id.quiz_tx_ans_1);
        tx_ans_2 = findViewById(R.id.quiz_tx_ans_2);
        tx_ans_3 = findViewById(R.id.quiz_tx_ans_3);
        tx_ans_4 = findViewById(R.id.quiz_tx_ans_4);
        tx_numbers = findViewById(R.id.quiz_tx_numbers);
        tx_wrong = findViewById(R.id.quiz_tx_wrong);
        tx_right = findViewById(R.id.quiz_tx_right);
        tx_score = findViewById(R.id.quiz_tx_score);
        rb_1 = findViewById(R.id.quiz_rb_1);
        rb_2 = findViewById(R.id.quiz_rb_2);
        rb_3 = findViewById(R.id.quiz_rb_3);
        rb_4 = findViewById(R.id.quiz_rb_4);
        btn_back = findViewById(R.id.quiz_back);
        lay_1 = findViewById(R.id.quiz_lay_1);
        lay_2 = findViewById(R.id.quiz_lay_2);
        lay_3 = findViewById(R.id.quiz_lay_3);
        lay_4 = findViewById(R.id.quiz_lay_4);

        tv_timer = (TextView) findViewById(R.id.tv_timer);

        helper=new DataBaseHelper(QuizActivity.this);
        /** ###################################################### */


        mpref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        mEditor = mpref.edit();
        MethodSetData();
        handler.postDelayed(runnable, 1000);

   /*     new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
               count++;

                if (count==10) {
                    WrongAnswer();


                }if (quiz_round<=9){
                    new Handler().postDelayed(this,1000);
                    tv_timer.setText("0"+(10-count)+"");
                }

            }
        }, 1000);*/


        /** ###################################################### */
        lay_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (quiz_correct_no == 0) {

                    rb_1.setImageResource(R.drawable.right_ans);
                    tx_ans_1.setTextColor(getResources().getColor(R.color.clr_green));
                    RightAnswer();
                } else {
                    rb_1.setImageResource(R.drawable.wrong_ans);
                    tx_ans_1.setTextColor(getResources().getColor(R.color.clr_red));
                    WrongAnswer();
                }
            }
        });
        lay_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (quiz_correct_no == 1) {

                    rb_2.setImageResource(R.drawable.right_ans);
                    tx_ans_2.setTextColor(getResources().getColor(R.color.clr_green));
                    RightAnswer();
                } else {
                    rb_2.setImageResource(R.drawable.wrong_ans);
                    tx_ans_2.setTextColor(getResources().getColor(R.color.clr_red));
                    WrongAnswer();
                }
            }
        });
        lay_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (quiz_correct_no == 2) {

                    rb_3.setImageResource(R.drawable.right_ans);
                    tx_ans_3.setTextColor(getResources().getColor(R.color.clr_green));
                    RightAnswer();
                } else {
                    rb_3.setImageResource(R.drawable.wrong_ans);
                    tx_ans_3.setTextColor(getResources().getColor(R.color.clr_red));
                    WrongAnswer();
                }
            }
        });
        lay_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (quiz_correct_no == 3) {

                    rb_4.setImageResource(R.drawable.right_ans);
                    tx_ans_4.setTextColor(getResources().getColor(R.color.clr_green));
                    RightAnswer();
                } else {
                    rb_4.setImageResource(R.drawable.wrong_ans);
                    tx_ans_4.setTextColor(getResources().getColor(R.color.clr_red));
                    WrongAnswer();
                }
            }
        });
        /** ###################################################### */

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void SetTimer() {
        try {
            String str_value = mpref.getString("data", "10");
            if (str_value.matches("")) {
                tv_timer.setText("Timer : 00");

            } else {

                if (mpref.getBoolean("finish", false)) {

                    tv_timer.setText("Timer : 00");
                } else {

                    tv_timer.setText("Timer : "+str_value);
                }
            }
        } catch (Exception e) {

        }
        int int_hours =10;
        mEditor.putString("data", date_time).commit();
        mEditor.putString("hours", "10").commit();
                calendar = Calendar.getInstance();
        simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
        date_time = simpleDateFormat.format(calendar.getTime());

        Intent intent_service = new Intent(getApplicationContext(), Timer_Service.class);
        startService(intent_service);
    }

    private void RightAnswer() {
        int right_ans = Integer.parseInt(tx_right.getText().toString());
        right_ans++;
        tx_right.setText(right_ans + "");
        CorrectedWords.add(data_ans[quiz_round]);

        int ttl_ans=quiz_round+1;
        tx_score.setText(tx_right.getText().toString()+"/"+ttl_ans);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (quiz_round < 9) {

                    quiz_round++;

                    MethodSetData();
                } else {

                    Quiz_Score_Wrong_Ans obj=new Quiz_Score_Wrong_Ans();
                    obj.setQ_Millis(System.currentTimeMillis()+"");

                    String chapterx = PreferenceManager.getDefaultSharedPreferences(QuizActivity.this).getString("chapter", "null");
                    obj.setQLessonNo(chapterx);
                    obj.setQ_Score(tx_right.getText().toString());
                    obj.setQ_Type("reading");


                    Log.d("tstng_quiz","chapter : "+chapterx);
                    Log.d("tstng_quiz","right : "+tx_right.getText().toString());


                    helper.InsertData_Quiz_Score(obj);
                    handler.removeCallbacks(runnable);
                    lay_1.setEnabled(false);
                    lay_2.setEnabled(false);
                    lay_3.setEnabled(false);
                    lay_4.setEnabled(false);
                    //finish();

                    CustomDialogClass cdd=new CustomDialogClass(QuizActivity.this,tx_right.getText().toString(),CorrectedWords,MistakenWords);
                    cdd.show();
                }
            }
        }, 1000);

    }

    private void WrongAnswer() {
        int wrong_ans = Integer.parseInt(tx_wrong.getText().toString());
        wrong_ans++;
        tx_wrong.setText(wrong_ans + "");
        MistakenWords.add(data_ans[quiz_round]);

        int ttl_ans=quiz_round+1;
        tx_score.setText(tx_right.getText().toString()+"/"+ttl_ans);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {


                Quiz_Score_Wrong_Ans obj=new Quiz_Score_Wrong_Ans();
                String chapterx = PreferenceManager.getDefaultSharedPreferences(QuizActivity .this).getString("chapter", "null");

                obj.setWLessonNo(chapterx);
                obj.setW_Word(data[quiz_round]);
                obj.setW_Meaning(data_ans[quiz_round]);

                helper.InsertData_Wrong_Ans(obj);
                if (quiz_round < 9) {

                    quiz_round++;
                    MethodSetData();
                } else {

                    obj.setQ_Millis(System.currentTimeMillis()+"");

                    obj.setQLessonNo(chapterx);
                    obj.setQ_Score(tx_right.getText().toString());
                    obj.setQ_Type("reading");


                    Log.d("tstng_quiz","chapter : "+chapterx);
                    Log.d("tstng_quiz","right : "+tx_right.getText().toString());


                    helper.InsertData_Quiz_Score(obj);
                    handler.removeCallbacks(runnable);
                    lay_1.setEnabled(false);
                    lay_2.setEnabled(false);
                    lay_3.setEnabled(false);
                    lay_4.setEnabled(false);
                    // finish();

                    CustomDialogClass cdd=new CustomDialogClass(QuizActivity.this,tx_right.getText().toString(),CorrectedWords,MistakenWords);
                    cdd.show();
                }
            }
        }, 1000);

    }

    private void MethodSetData() {

        count=0;

        /** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
        rb_1.setImageResource(R.drawable.cbox);
        rb_2.setImageResource(R.drawable.cbox);
        rb_3.setImageResource(R.drawable.cbox);
        rb_4.setImageResource(R.drawable.cbox);
        /** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
        tx_ans_1.setTextColor(getResources().getColor(R.color.clr_black));
        tx_ans_2.setTextColor(getResources().getColor(R.color.clr_black));
        tx_ans_3.setTextColor(getResources().getColor(R.color.clr_black));
        tx_ans_4.setTextColor(getResources().getColor(R.color.clr_black));
        /** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */

        /** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
        int num = quiz_round + 1;
        tx_numbers.setText(num + "/10");
        tx_meaning.setText(data[quiz_round]);

        String[] answers = new String[4];
        final int min = 1;
        final int max = words_lst.length - 1;
        quiz_correct_no = new Random().nextInt((3 - 1) + 1) + 1;

        Log.d("tstng_method", "max : " + max);
        for (int i = 0; i < 4; i++) {
            Log.d("tstng_method", "for loop : " + i);

            boolean is_exists = true;

            if (i == quiz_correct_no) {
                answers[i] = data_ans[quiz_round];
                Log.d("tstng_method", "correct ans round : " + quiz_round);
                Log.d("tstng_method", "correct ans : " + data_ans[0]);
                Log.d("tstng_method", "correct ans : " + answers[i]);

            } else {
                answers[i]=dataBaseHelper.GetRandVocab();
//                Log.d("tstng_method", "for loop : " + is_exists);
//                while (is_exists) {
//                    Log.d("tstng_method", "while in for loop : " + is_exists);
//                    final int random = new Random().nextInt((max - min) + 1) + min;
//
//
//
//
//                    if (!Arrays.asList(data_index).contains(random)) {
//
//                        if (!Arrays.asList(answers).contains(words_lst[random])) {
//
//
//                            answers[i] = words_lst[random];
//                            Log.d("tstng_method", "word  in list : " + answers[i]);
//                            is_exists = false;
//                        } else
//                            Log.d("tstng_method", "word exist in list : " + words_lst[random]);
//
//                    } else
//                        Log.d("tstng_method", "word exist in list : " + words_lst[random]);
//
//                }
            }


        }

        Log.d("tstng_method", "answers : " + answers.length);
        Log.d("tstng_method", "answers no: " + quiz_correct_no);

        tx_ans_1.setText(answers[0].replace("\"",""));
        tx_ans_2.setText(answers[1].replace("\"",""));
        tx_ans_3.setText(answers[2].replace("\"",""));
        tx_ans_4.setText(answers[3].replace("\"",""));

    }


    private void AlertBoxMethod(){
        new AlertDialog.Builder(QuizActivity.this)
                .setTitle("Selection")
                .setMessage("Select Quiz type")

                // Specifying a listener allows you to take an action before dismissing the dialog.
                // The dialog is automatically dismissed when a dialog button is clicked.
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Continue with delete operation

               finish();
                    }
                })

                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();


    }


    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String str_time = intent.getStringExtra("time");
            tv_timer.setText("Timer : "+str_time);

        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(broadcastReceiver,new IntentFilter(Timer_Service.str_receiver));

    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(broadcastReceiver);
    }
}
